
 $(function() {
    	  $('button[type=submit]').click(function(e) {
    	    e.preventDefault();
    	    //Disable submit button
    	    $(this).prop('disabled',true);
    	    
    	    var form = document.forms[0];
    	    var formData = new FormData(form);
    	    var attendanceDate=$("#attendanceDate").val();
    	    var id=$("#user_id").val();
    	    // Ajax call for file uploaling
    	    var ajaxReq = $.ajax({
    	      url : 'uploadattendance.page?attendanceDate='+attendanceDate+"&id="+id,
    	      type : 'POST',
    	      data : formData,
    	      cache : false,
    	      contentType : false,
    	      processData : false,
    	      xhr: function(){
    	        //Get XmlHttpRequest object
    	         var xhr = $.ajaxSettings.xhr() ;
    	        
    	        //Set onprogress event handler 
    	         xhr.upload.onprogress = function(event){
    	          	var perc = Math.round((event.loaded / event.total) * 100);
    	          	$('#progressBar').text(perc + '%');
    	          	$('#progressBar').css('width',perc + '%');
    	         };
    	         return xhr ;
    	    	},
    	    	beforeSend: function( xhr ) {
    	    		//Reset alert message and progress bar
    	    		
    	    		$('#progressBar').text('');
    	    		$('#progressBar').css('width','0%');
    	              }
    	    });
    	  
    	    // Called on success of file upload
    	    ajaxReq.done(function(msg) {
    	      
    	      $('input[type=file]').val('');
    	      $('button[type=submit]').prop('disabled',false);
    	    });
    	    
    	    // Called on failure of file upload
    		    ajaxReq.fail(function(jqXHR) {
    		    
    		      $('button[type=submit]').prop('disabled',false);
    		    });
    	  });
    	});





function userAttendance()
{	
	var user_id=$("#user_id").val();
	var time=$("#time").val();
	var attendance=$("#attendance").val();
	var att_date=$("#att_date").val();
		alert(user_id+" "+time+" "+attendance+" "+att_date);
}