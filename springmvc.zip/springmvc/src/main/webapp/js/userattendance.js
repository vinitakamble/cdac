


	function userAttendanceExcel()
	{
		var user_id=$("#user_id").val();
		var attendance=$("#attendance_date").val();
		var att_date=$("#file_upload").val();
		alert(user_id+" "+attendance+" "+att_date);
	};
	


function userAttendance()
{	
	var user_id=$("#user_id").val();
	var time=$("#time").val();
	var attendance=$("#attendance").val();
	var att_date=$("#att_date").val();
		alert(user_id+" "+time+" "+attendance+" "+att_date);
}