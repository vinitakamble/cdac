function validate()
{
		var image =document.getElementById("file_upload").value;
		if(image!='')
		{
			var checkimg = image.toLowerCase();
				if (!checkimg.match(/(\.jpg|\.png|\.JPG|\.PNG|\.jpeg|\.JPEG)$/))
				{
					alert("Please enter Image File Extensions .jpg,.png,.jpeg");
					document.getElementById("file_upload").focus();
					return false;
				}
		}
		return true;
} 