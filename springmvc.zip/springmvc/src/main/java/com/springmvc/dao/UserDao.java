package com.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.entity.UserRegistration;

@Component
public class UserDao {
	
	
	
	@PersistenceContext
	EntityManager em;
	
	@Transactional
	public void save(UserRegistration obj)
	{
		em.merge(obj);
	}
	
	@Transactional
	public List<UserRegistration> getUser(UserRegistration user)
	{
		 String query="from UserRegistration where userName='"+user.getUserName()+"'and password='"+user.getPassword()+"'";
		TypedQuery<UserRegistration> q=(TypedQuery<UserRegistration>) em.createQuery(query);
		List<UserRegistration> e= (List<UserRegistration>) q.getResultList();
		return e;
	}
	
}
