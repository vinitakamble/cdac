package com.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.entity.Attendance;
import com.springmvc.entity.UserRegistration;

@Component
public class UserDao {
	
	
	
	@PersistenceContext
	EntityManager em;
	
	@Transactional
	public void save(UserRegistration obj)
	{
		em.merge(obj);
	}
	
	@Transactional
	public List<UserRegistration> getUser(UserRegistration user)
	{
		 String query="from UserRegistration where userName='"+user.getUserName()+"'and password='"+user.getPassword()+"'";
		TypedQuery<UserRegistration> q=(TypedQuery<UserRegistration>) em.createQuery(query);
		List<UserRegistration> e= (List<UserRegistration>) q.getResultList();
		return e;
	}
	
	@Transactional
	public List<Attendance> getAtt(int id)
	{
		
		String sql="from Attendance a where "
				+ "a.userRegi='"+id+"'";
		TypedQuery<Attendance> q=(TypedQuery<Attendance>)em.createQuery(sql);
			List<Attendance> e=q.getResultList();
		return e;
	}
	
	@Transactional
	public void uploadUserAtt(Attendance a)
	{
		em.persist(a);
	}
}
