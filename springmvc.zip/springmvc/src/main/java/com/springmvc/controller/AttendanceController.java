package com.springmvc.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.entity.Attendance;
import com.springmvc.service.UserService;

@Controller
public class AttendanceController {

	@Autowired
	UserService uService;
	
	
	
	@RequestMapping(value="/attendance.page",method=RequestMethod.GET)
	public String getStudentAtt(Attendance a,Map<String,List<Attendance>> map)
	{
		 List<Attendance> att=uService.getUserAttendance(a);
		 map.put("attendance", att);
		
		 return "jsp/attendance.jsp";
	}
	
	@RequestMapping(value="/uploadattendance.page",method=RequestMethod.POST)
	public void uploadAttendance(@RequestParam("file") CommonsMultipartFile file,@RequestParam("attendanceDate") String attendanceDate,@RequestParam("id") int id,HttpSession session) throws Exception
	{
		
		uService.uploadExcel(file, attendanceDate,id, session);
	}
}
