package com.springmvc.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.dao.UserDao;
import com.springmvc.entity.Address;
import com.springmvc.entity.Attendance;
import com.springmvc.entity.UserRegistration;
import com.springmvc.entity.UserType;
import com.springmvc.service.EncryptionService;
import com.springmvc.service.UserService;

//Login and Registration controller


@Controller
public class UserController {
	
	 
	@Autowired
	UserService uService;
	
	@Autowired
	EncryptionService eService;
	
	
	@RequestMapping(value="/regi.page",method=RequestMethod.POST)
	public String registration(UserRegistration userregi,UserType userType,Address address,@RequestParam("file_upload") CommonsMultipartFile file,HttpSession session) throws Exception
	{
		
		userregi.setUserType(userType);
		String password=eService.encrypt(userregi.getPassword());
		userregi.setPassword(password);
		uService.signup(userregi, address, file, session);
		
	  return "login.jsp";
	}
	
	@RequestMapping(value="/login.page",method=RequestMethod.POST)
	public String login(Map<String,List<UserRegistration>> map,UserRegistration user) throws Exception
	{
	
		String password=eService.encrypt(user.getPassword());
		user.setPassword(password);
		List<UserRegistration> uLogin=uService.getUserData(user);
		
		for(UserRegistration userLogin:uLogin)
		{
			map.put("message", uLogin);
		
			UserType uType =userLogin.getUserType();
			if(uType.getUserType().equals("admin"))
			{
				return "jsp/admin.jsp";
			}
			else if(uType.getUserType().equals("student"))
			{		
				return "jsp/student.jsp";
			}
			else if(uType.getUserType().equals("teacher"))
			{
				return "jsp/student.jsp";
			}
		}
	  return "login.jsp";
	}
	
	
	
}
