package com.springmvc.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.dao.UserDao;
import com.springmvc.entity.Address;
import com.springmvc.entity.UserRegistration;
import com.springmvc.entity.UserType;
import com.springmvc.service.EncryptionService;
import com.springmvc.service.UserService;

//Login and Registration controller


@Controller
public class UserController {
	
	 
	@Autowired
	UserService uService;
	
	@Autowired
	EncryptionService eService;
	
	
	@RequestMapping(value="/regi.page",method=RequestMethod.POST)
	public String registration(UserRegistration userregi,Address address,@RequestParam("file_upload") CommonsMultipartFile file,HttpSession session) throws Exception
	{
		System.out.println(userregi.getPassword());
		String password=eService.encrypt(userregi.getPassword());
		System.out.println(password);
		userregi.setPassword(password);
		uService.signup(userregi, address, file, session);
		return "login.jsp";
	}
	
	@RequestMapping(value="/login.page",method=RequestMethod.POST)
	public String login(Map<String,List<UserRegistration>> map,UserRegistration user) throws Exception
	{
	
		String password=eService.encrypt(user.getPassword());
		
		user.setPassword(password);
		List<UserRegistration> uLogin=uService.getUserData(user);
		
		
		
		for(UserRegistration userLogin:uLogin)
		{
			UserType uType =userLogin.getUserType();
			if(user.getUserName().equals(userLogin.getUserName()) && user.getPassword().equals(userLogin.getPassword()) && uType.getUserType().equals("admin"))
			{
				map.put("message", uLogin);
				return "jsp/admin.jsp";
			}
			else if(user.getUserName().equals(userLogin.getUserName()) && user.getPassword().equals(userLogin.getPassword()) && uType.getUserType().equals("teacher"))
			{
				map.put("message", uLogin);
				return "jsp/student.jsp";
			}
		}
		return "login.jsp";
	}
	
	
	
}
