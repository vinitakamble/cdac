package com.springmvc.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_usertype")
public class UserType 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String userType;
	
	@OneToOne(cascade=CascadeType.ALL,mappedBy="userType")
	private UserRegistration user;

	
	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getUserType() 
	{
		return userType;
	}

	public void setUserType(String userType) 
	{
		this.userType = userType;
	}

	public UserRegistration getUser() 
	{
		return user;
	}

	public void setUser(UserRegistration user)
	{
		this.user = user;
	}
	
}
