package com.springmvc.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.entity.Address;
import com.springmvc.entity.UserRegistration;

public interface UserInterface {
	  String UPLOAD_DIRECTORY ="/profile_image"; 
	  String UPLOAD_EXCEL="/attendanceexcel";
	  void signup(UserRegistration userregi,Address address,CommonsMultipartFile file,HttpSession session)throws Exception;
	  List<UserRegistration> getUserData(UserRegistration user);
}
