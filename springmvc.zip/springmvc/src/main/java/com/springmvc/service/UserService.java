package com.springmvc.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.dao.UserDao;
import com.springmvc.entity.Address;
import com.springmvc.entity.Attendance;
import com.springmvc.entity.UserRegistration;

@Service
public class UserService implements UserInterface
{
	@Autowired
	UserDao gDao;
	
	
	public void signup(UserRegistration userregi,Address address,CommonsMultipartFile file,HttpSession session) throws Exception
	{
		
		ServletContext context = session.getServletContext();  // to get path of current project
		String path = context.getRealPath(UPLOAD_DIRECTORY); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
		
		File file_c=new File(path);
		
			if(!file_c.exists())
			{
				file_c.mkdir();
			}
		
			address.setUserregistration(userregi);   //to set registration for one to one mapping
			userregi.setAddress(address);  // to set address for one to one mapping
			userregi.setImage(UPLOAD_DIRECTORY+"/"+filename); // to set image path
			
			gDao.save(userregi);  // insert data 
		          
		    byte[] bytes = file.getBytes();  //to read the image in bytes
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
		         new File(path + File.separator + filename)));  // new FileOutputStream for write  and create folder for storing image(new File())
		    stream.write(bytes);    // write file 
		    stream.flush();   // empty stream
		    stream.close();  // close file		           
	}
	
	
	public List<UserRegistration> getUserData(UserRegistration user)
	{
		//System.out.println(user.getPassword());
		List<UserRegistration> uLogin=gDao.getUser(user);
		return uLogin;
	}
	
	public List<Attendance> getUserAttendance(Attendance a)
	{
		List<Attendance> att=gDao.getAtt(a.getId());
		return att;
	}
	
}
