package com.springmvc.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.springmvc.dao.UserDao;
import com.springmvc.entity.Address;
import com.springmvc.entity.Attendance;
import com.springmvc.entity.LectureTime;
import com.springmvc.entity.UserRegistration;

@Service
public class UserService implements UserInterface
{
	@Autowired
	UserDao gDao;
	
	
	public void signup(UserRegistration userregi,Address address,CommonsMultipartFile file,HttpSession session) throws Exception
	{
		
		ServletContext context = session.getServletContext();  // to get path of current project
		String path = context.getRealPath(UPLOAD_DIRECTORY); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
		
		File file_c=new File(path);
		
			if(!file_c.exists())
			{
				file_c.mkdir();
			}
		
			address.setUserregistration(userregi);   //to set registration for one to one mapping
			userregi.setAddress(address);  // to set address for one to one mapping
			userregi.setImage(UPLOAD_DIRECTORY+"/"+filename); // to set image path
			
			gDao.save(userregi);  // insert data 
		          
		    byte[] bytes = file.getBytes();  //to read the image in bytes
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
		         new File(path + File.separator + filename)));  // new FileOutputStream for write  and create folder for storing image(new File())
		    stream.write(bytes);    // write file 
		    stream.flush();   // empty stream
		    stream.close();  // close file		           
	}
	
	
	public List<UserRegistration> getUserData(UserRegistration user)
	{
		//System.out.println(user.getPassword());
		List<UserRegistration> uLogin=gDao.getUser(user);
		return uLogin;
	}
	
	public List<Attendance> getUserAttendance(Attendance a)
	{
		List<Attendance> att=gDao.getAtt(a.getId());
		return att;
	}
	
	public void uploadExcel(CommonsMultipartFile file,String attendanceDate,int id,HttpSession session) throws Exception
	{
		ServletContext context = session.getServletContext();  // to get path of current project
		String path = context.getRealPath(UPLOAD_EXCEL); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
		File file_c=new File(path);
		
			if(!file_c.exists())
			{
				file_c.mkdir();
			}
			 byte[] bytes = file.getBytes();  //to read the image in bytes
			    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
			         new File(path + File.separator + filename)));  // new FileOutputStream for write  and create folder for storing image(new File())
			    stream.write(bytes);    // write file 
			    stream.flush();   // empty stream
			    stream.close();  // close file
			    
			    
		 Workbook wb = WorkbookFactory.create(new FileInputStream(path + File.separator + filename)); // Or foo.xlsx
	for(int i=0;i<wb.getNumberOfSheets();i++)
	{
		 Sheet s = wb.getSheetAt(i);
		 
		 for(int j=1;j<=s.getLastRowNum();j++)
		 {
			 Row r = s.getRow(j);
			 UserRegistration u=new UserRegistration();
			 Attendance a=new Attendance();
			 LectureTime l=new LectureTime();
			 SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");
			u.setId((int)r.getCell(0).getNumericCellValue());// for roll number
			a.setUserRegi(u);
			a.setAttendanceDate(sdf.format(r.getCell(1).getDateCellValue()));
			a.setAttendanceType(r.getCell(2).getStringCellValue());
			l.setId((int)r.getCell(3).getNumericCellValue());
			a.setLectureTime(l);
			gDao.uploadUserAtt(a);
			// System.out.println(+r" "++" "+r.getCell(2)+" "+r.getCell(3));
		 }
	} 
		   
	}
}
