package com.cdacportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService 
{
	 @Autowired
	 private JavaMailSender mailSender;
	 protected static final String emailFrom="teks712@gmail.com";
	 
	public String sendEmail(String mailTo,String subject,String message)
	{
		try
		{
			SimpleMailMessage messageObj = new SimpleMailMessage();
				messageObj.setTo(mailTo);
			    messageObj.setFrom(emailFrom);
			    messageObj.setText(message);
			    messageObj.setSubject(subject); 
			  mailSender.send(messageObj);
			return "Mail Send SuccessFully";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	  return "Email Not Send";
	}
}
