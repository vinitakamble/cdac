package com.cdacportal.service;

public interface EncrpytionInterface {
	
	String KEY = "Bar12345Bar12345";
	String AES = "AES";
	
	public String encrypt(String password) throws Exception;
	public String decrypt(String password) throws Exception;
}
