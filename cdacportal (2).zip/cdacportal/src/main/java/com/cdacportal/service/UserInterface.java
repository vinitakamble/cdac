package com.cdacportal.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.entity.Address;
import com.cdacportal.entity.UserRegistration;


public interface UserInterface
{
	  String UPLOAD_DIRECTORY ="/profile_image"; 
	  String UPLOAD_EXCEL="/attendanceexcel";
	  String UPLOAD_USEREXCEL="/userexcel";
	  String UPLOAD_ATTACHMENT="/studentattchments";
	  String UPLOAD_SYLLABUS="/modulesyllabus";
	  String UPLOAD_EXAM_SCHEDULE="/examschedule";
	  String UPLOAD_IMAGE ="/portalimage";
	  String UPLOAD_STUDYMATERIAL="/modulestudymaterial";
	  void signup(UserRegistration userregi,Address address,CommonsMultipartFile file,HttpSession session)throws Exception;
	  List<UserRegistration> getUserData(UserRegistration user);
}
