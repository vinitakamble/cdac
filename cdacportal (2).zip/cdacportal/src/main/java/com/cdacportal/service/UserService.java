package com.cdacportal.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.dao.UserDao;
import com.cdacportal.entity.Address;
import com.cdacportal.entity.Attendance;
import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.ExamSchedule;
import com.cdacportal.entity.PortalImages;
import com.cdacportal.entity.StudyMaterial;
import com.cdacportal.entity.Syllabus;
import com.cdacportal.entity.UploadAttachment;
import com.cdacportal.entity.UserRegistration;


/**
 * @author Tekchand
 *
 */
@Service
public class UserService  implements UserInterface
{
	@Autowired
	UserDao gDao;
	
	 @Autowired
	 private JavaMailSender mailSender;
	 
	 @Autowired
	 EncryptionService eService;
	 
	 protected static final String emailFrom="teks712@gmail.com";
	 
	/* This Code for uploading File */
	
	public String uploadFile(ServletContext context,CommonsMultipartFile file,String uploadDirectory) throws Exception
	{
		String path = context.getRealPath("/resources/static"+uploadDirectory); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
	
		File file_c=new File(path);
			//filename=filename.replaceAll(filename, arg1);
			if(!file_c.exists())
			{
				file_c.mkdir();
			}
			
			byte[] bytes = file.getBytes();  //to read the image in bytes
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
		         new File(path + File.separator + filename)));  // new FileOutputStream for write  and create folder for storing image(new File())
		    stream.write(bytes);    // write file 
		    stream.flush();   // empty stream
		    stream.close();  // close file	
		return uploadDirectory+"/"+filename;
	}
	
	
	
	/* This Code for Admin and Teacher Registration */
	public void signup(UserRegistration userregi,Address address,CommonsMultipartFile file,HttpSession session) throws Exception
	{
		
		    ServletContext context = session.getServletContext();  // to get path of current project
			address.setUserregistration(userregi);   //to set registration for one to one mapping
			userregi.setAddress(address);  // to set address for one to one mapping
			userregi.setImage(uploadFile(context,file,UPLOAD_DIRECTORY)); // to set image path
			gDao.save(userregi);  // insert data 
		          	    	           
	}
	
	/*	This code for Find User Admin and Teacher */
	
	public List<UserRegistration> getUserData(UserRegistration user)
	{
		//System.out.println(user.getPassword());
		List<UserRegistration> uLogin=gDao.getUser(user);
		return uLogin;
	}
	
	/*	This code for Find User Student */
	
	public List<CreateUser> getUserStudentData(CreateUser user)
	{
		
		List<CreateUser> uLogin=gDao.getStudent(user);
		return uLogin;
	}
	
	/*	This code for Find  Student Attendance */
	
	public List<Attendance> getUserAttendance()
	{
		List<Attendance> att=gDao.getAllStudentAttendance();
		return att;
	}
	
	/*	This code for Student Registration using excel upload by admin user
	 * 		Excel should be rollno string,FormNo string ,Password string
	 *  */
	
	public String sendEmail(String mailTo,String subject,String message)
	{
		try
		{
			SimpleMailMessage messageObj = new SimpleMailMessage();
				messageObj.setTo(mailTo);
			    messageObj.setFrom(emailFrom);
			    messageObj.setText(message);
			    messageObj.setSubject(subject); 
			  mailSender.send(messageObj);
			return "Mail Send SuccessFully";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	  return "Email Not Send";
	}
	
	
	public String uploadExcelUser(CommonsMultipartFile file,HttpSession session) 
	{
		ServletContext context = session.getServletContext();  // to get path of current project
		String path = context.getRealPath("/resources/static"+UPLOAD_USEREXCEL); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
		String msg=null;
		
		try 
		{
			uploadFile(context, file, UPLOAD_USEREXCEL);
		    
			 Workbook wb = WorkbookFactory.create(new FileInputStream(path + File.separator + filename)); // Or foo.xlsx
			for(int i=0;i<wb.getNumberOfSheets();i++)
			{
				 Sheet s = wb.getSheetAt(i);
				 
				 for(int j=1;j<=s.getLastRowNum();j++)
				 {
					 Row r = s.getRow(j);
					CreateUser cUser=new CreateUser();
					
					Date currDate=new Date();
					SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");
					 
					cUser.setRollNo(new DataFormatter().formatCellValue(r.getCell(0)));// for roll number
					cUser.setFormNo(new DataFormatter().formatCellValue(r.getCell(1)));   //form Number
					cUser.setPassword(new DataFormatter().formatCellValue(r.getCell(2)));  // for password
					cUser.setUploadDate(sdf.format(currDate));
					cUser.setEmailId(new DataFormatter().formatCellValue(r.getCell(3)));
					gDao.createUser(cUser);
					String message="Please Find The UserName and Password Below:\n"+"UserName="+cUser.getRollNo()+"\n"+"Password="+cUser.getPassword();
					msg=sendEmail(cUser.getEmailId(),"Your Cdac Portal Credentilas generated by cdac admin", message);
					
				 }
			} 
			//return msg;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return msg;
		}
		return msg;
		
	}
	
/*	This code for Check User Exist or not */
	
	public boolean validUser(String userName)
	{
		boolean user=gDao.getUserName(userName);
		return user;
	}

	/*	This code for Check Email Exist or not */
	
	public boolean validEmail(String emailId) 
	{
		boolean e=gDao.getEmailId(emailId);
		return e;
	}

	/* This Code for Student Password Change */
	
	public String  changeUserPassword(String userName, String oldPassword, String newPassword,Boolean action) 
	{
		String msg="";
		if(action)
		{
			msg=gDao.updatePassword(userName,oldPassword,newPassword);
			return msg;
		}
		else
		{
			try
			{
				newPassword=eService.encrypt(newPassword);
				oldPassword=eService.encrypt(oldPassword);
				msg=gDao.updateAdminPassword(userName,oldPassword,newPassword);
				return msg;
			}
			catch (Exception e) {
				e.printStackTrace();
				msg="Old Password Not Matched";
			}
		}
	  return msg;
	}
	
	
	public String uploadImage(ArrayList<CommonsMultipartFile> fileList,HttpSession session,int studentt_id) throws Exception
	{
		
		ServletContext context = session.getServletContext();  // to get path of current project
		UploadAttachment uAttach=new UploadAttachment();
		int i=0;
		for(CommonsMultipartFile files:fileList)
		{
			i++;
		//	System.out.println(context.getRealPath(UPLOAD_ATTACHMENT)+" "+uploadFile(context,files,UPLOAD_ATTACHMENT));
			if(i==1)
			uAttach.setTenupload(uploadFile(context,files,UPLOAD_ATTACHMENT)); // to set image path	
			else if(i==2)
			uAttach.setTwelveupload(uploadFile(context,files,UPLOAD_ATTACHMENT));
			else if(i==3)
			uAttach.setDiploma(uploadFile(context,files,UPLOAD_ATTACHMENT));
			else if(i==4)
			uAttach.setDegree(uploadFile(context,files,UPLOAD_ATTACHMENT));
			else if(i==5)
			uAttach.setPhoto(uploadFile(context,files,UPLOAD_ATTACHMENT));
			else if(i==6)
			uAttach.setSignature(uploadFile(context,files,UPLOAD_ATTACHMENT));
		}
		CreateUser c=new CreateUser();
		c.setId(studentt_id);
		uAttach.setStudent_id(c);
		gDao.save(uAttach);  // insert data 
		return "success";
	}
	
	public void uploadSyllabus(Syllabus s,CommonsMultipartFile file,HttpSession session) throws Exception
	{
		ServletContext context = session.getServletContext();  // to get path of current project
		/* String path = context.getRealPath(UPLOAD_SYLLABUS); // to bind the folder name
		String filename = file.getOriginalFilename();  //to get file name
	
*/		 
		SimpleDateFormat sdf=new SimpleDateFormat("Y");
		SimpleDateFormat sdf1=new SimpleDateFormat("M");
		Date d=new Date();
		
		if(Integer.parseInt(sdf1.format(d))<=12 && Integer.parseInt(sdf1.format(d))>1)
		{
			try
			{
				s.setBatchyear("August"+sdf.format(d));
				s.setFilePath(uploadFile(context, file, UPLOAD_SYLLABUS));
				System.out.println(context.getRealPath(UPLOAD_SYLLABUS));
				//Syllabus s=new Syllabus();
			//	s.setSubjectName(subjectName);
				gDao.save(s);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
		}
		else if(Integer.parseInt(sdf1.format(d))>=1 && Integer.parseInt(sdf1.format(d))<8)
		{
			try
			{
				s.setBatchyear("February"+sdf.format(d));
				s.setFilePath(uploadFile(context, file, UPLOAD_SYLLABUS));
				System.out.println(context.getRealPath(UPLOAD_SYLLABUS));
				//Syllabus s=new Syllabus();
			//	s.setSubjectName(subjectName);
				gDao.save(s);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		
	}
	
	public Boolean examScheduleUpload(ExamSchedule e,CommonsMultipartFile file,HttpSession session)
	{
		ServletContext context = session.getServletContext();  // to get path of current project
	  try 
	  {
		  e.setFile(uploadFile(context, file, UPLOAD_EXAM_SCHEDULE));
		  System.out.println(context.getRealPath(UPLOAD_EXAM_SCHEDULE));
		  gDao.save(e);
	  }
	  catch(Exception ex)
	  {
		  return false;
	  }
		return true;
	}
	
	//code for portal images
		public Boolean portalimageUpload(PortalImages e,CommonsMultipartFile file,HttpSession session)
		{
			ServletContext context = session.getServletContext();  // to get path of current project
		  try 
		  {
			  e.setImage(uploadFile(context, file, UPLOAD_IMAGE));
			  System.out.println(context.getRealPath(UPLOAD_IMAGE));
			  gDao.save(e);
		  }
		  catch(Exception ex)
		  {
			  return false;
		  }
			return true;
		}
	

		public void uploadStudyMaterial(StudyMaterial s,CommonsMultipartFile file,HttpSession session) throws Exception
		{
			ServletContext context = session.getServletContext();  // to get path of current project
			/* String path = context.getRealPath(UPLOAD_SYLLABUS); // to bind the folder name
			String filename = file.getOriginalFilename();  //to get file name
		
	*/		 
			SimpleDateFormat sdf=new SimpleDateFormat("Y");
			SimpleDateFormat sdf1=new SimpleDateFormat("M");
			Date d=new Date();
			
			if(Integer.parseInt(sdf1.format(d))<=12 && Integer.parseInt(sdf1.format(d))>1)
			{
				try
				{
					s.setBatchyear("August"+sdf.format(d));
					s.setFilePath(uploadFile(context, file, UPLOAD_STUDYMATERIAL));
					System.out.println(context.getRealPath(UPLOAD_STUDYMATERIAL));
					//Syllabus s=new Syllabus();
				//	s.setSubjectName(subjectName);
					gDao.save(s);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				
			}
			else if(Integer.parseInt(sdf1.format(d))>=1 && Integer.parseInt(sdf1.format(d))<8)
			{
				try
				{
					s.setBatchyear("February"+sdf.format(d));
					s.setFilePath(uploadFile(context, file, UPLOAD_STUDYMATERIAL));
					System.out.println(context.getRealPath(UPLOAD_STUDYMATERIAL));
					//Syllabus s=new Syllabus();
				//	s.setSubjectName(subjectName);
					gDao.save(s);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
			
		}
}
