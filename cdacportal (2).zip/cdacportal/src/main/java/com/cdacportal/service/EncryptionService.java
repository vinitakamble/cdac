package com.cdacportal.service;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.stereotype.Service;

/**
 * @author Tekchand
 *
 */
@Service
public class EncryptionService implements EncrpytionInterface {
	
/*	 Encrpyt the password using key for security purpose */
	
	 public String encrypt(String password) throws Exception
	 {
			 Key aesKey = new SecretKeySpec(KEY.getBytes(), AES);
	         Cipher cipher = Cipher.getInstance(AES);
	         // encrypt the text
	         cipher.init(Cipher.ENCRYPT_MODE, aesKey);
	         byte[] encrypted = cipher.doFinal(password.getBytes());
	      return  new String(encrypted);
	    }

/*	 decrypt the password using key for security purpose */
	 
	   public String decrypt(String password) throws Exception 
	   {
		    Key aesKey = new SecretKeySpec(KEY.getBytes(), AES);
	        Cipher cipher = Cipher.getInstance(AES);
	        // decrypt the text
		    cipher.init(Cipher.DECRYPT_MODE, aesKey);
		    byte[] encrypted = cipher.doFinal(password.getBytes());
            String decrypted = new String(cipher.doFinal(encrypted));
		  return decrypted;
	    }
}
