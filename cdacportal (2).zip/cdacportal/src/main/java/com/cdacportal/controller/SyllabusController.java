package com.cdacportal.controller;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.dao.UserDao;
import com.cdacportal.entity.StudyMaterial;
import com.cdacportal.entity.Syllabus;
import com.cdacportal.service.UserService;

@Controller
public class SyllabusController {

	@Autowired
	UserDao uDao;
	@Autowired
	UserService uService;
	

	@RequestMapping(value="doUpload",method=RequestMethod.POST)
	public String handleFileUpload(Syllabus s,@ RequestParam("osFile") CommonsMultipartFile file,HttpSession session,Map<String,String> errList) throws Exception
	{
			try
			{
				uService.uploadSyllabus(s,file,session);
				errList.put("errMsg", "File Uploaded SuccessFully");
				  return "UploadSyllabus";
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		  errList.put("errMsg", "File Not Uploaded");
		return "UploadSyllabus";
		
		
	}
	
	@RequestMapping(value="insttitueSyllabus",method=RequestMethod.GET)
	public String syllabusAction(Map<String,List<Syllabus>> mapList) throws Exception
	{
			List<Syllabus>syllabusList=uDao.getAllSyllabus();
			
			// This code for fetching object and put into map 
			
				 mapList.put("syllabusList",syllabusList);
			
		 
		return "instsyllabus";
		
		
	}
	
	@RequestMapping(value="insttituestudymaterial",method=RequestMethod.GET)
	public String studyMaterialAction(Map<String,List<StudyMaterial>> mapList) throws Exception
	{
			List<StudyMaterial>syllabusList=uDao.getAllStudyMaterial();
			
			// This code for fetching object and put into map 
			
				 mapList.put("syllabusList",syllabusList);
			
		 
		return "inststudymaterial";
		
		
	}
	
	@RequestMapping(value="studymaterial",method=RequestMethod.POST)
	public String handleStudyMaterial(StudyMaterial s,@ RequestParam("osFile") CommonsMultipartFile file,HttpSession session,Map<String,String> errList) throws Exception
	{
			try
			{
				uService.uploadStudyMaterial(s,file,session);
				errList.put("errMsg", "File Uploaded SuccessFully");
				  return "studyMaterial";
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		  errList.put("errMsg", "File Not Uploaded");
		return "studyMaterial";
			
	}
	
}
