package com.cdacportal.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.dao.EducationDao;
import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.EducationDetail;
import com.cdacportal.entity.Event;
import com.cdacportal.entity.ExamSchedule;
import com.cdacportal.entity.PortalImages;
import com.cdacportal.entity.UploadAttachment;
import com.cdacportal.service.UserService;

@Controller
public class EducationController 
{
	@Autowired
	EducationDao eDao;
	
	@Autowired
	UserService uService;
	String UPLOAD_ATTACHMENT="/studentattchments";
	
		@RequestMapping(value="education",method=RequestMethod.POST)
		private String insertEducation(EducationDetail edu,@RequestParam("studentt_id")int studentt_id,Map<String,String>errList)
		{   
			try 
			{
				CreateUser c=new CreateUser();
				c.setId(studentt_id);
				edu.setStudent_id(c);
				
				eDao.saveEducation(edu);
				return "attachments";
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			errList.put("errMsg", "Educational Detail Not Inserted");
		  return "educationdetail";
		}
		
		@RequestMapping(value="attachment",method=RequestMethod.POST)
		public  String studentAttachment(@RequestParam("tenMarksheet") CommonsMultipartFile file
				,@RequestParam("twelveMarksheet") CommonsMultipartFile file1,
				@RequestParam("Diploma") CommonsMultipartFile file2,
				@RequestParam("photo") CommonsMultipartFile file3,
				@RequestParam("signature") CommonsMultipartFile file4,
				@RequestParam("degree") CommonsMultipartFile file5
				,HttpSession session,Map<String,String>errorLimit,@RequestParam("studentt_id")int studentt_id) throws Exception
		{
			final long limit = 50 * 1024;
			
			ArrayList<CommonsMultipartFile> fileList=new ArrayList<CommonsMultipartFile>();
			fileList.add(file);
			fileList.add(file1);
			fileList.add(file2);
			fileList.add(file3);
			fileList.add(file4);
			fileList.add(file5);
			for(CommonsMultipartFile files:fileList)
			{
				if (files.getSize() > limit) 
				{
					errorLimit.put("errMsg", "Maximum Limit Should be 50KB");
					return "attachments";
			       // throw new MaxUploadSizeExceededException(limit);
			    }
			}
			uService.uploadImage(fileList, session,studentt_id);
			errorLimit.put("errMsg", "Images Uploaded SuccessFully");
			return "attachments";
		}
		
		@RequestMapping(value="ExamScheduleController",method=RequestMethod.POST)
		public String examscheduleadd(ExamSchedule examschedule,@RequestParam("fileUpload")CommonsMultipartFile file,HttpSession session,Map<String,String> errMsg) throws Exception
		{
			
			//System.out.println("hii");
			Boolean flag=uService.examScheduleUpload(examschedule, file, session);
				if(flag)
				{
					errMsg.put("errMsg","File Uploaded SuccessFully");
					System.out.println("done");
				}
				else
					errMsg.put("errMsg","File Not Uploaded");
			
			return "examschedule";
			
		}
		
		@RequestMapping(value="portalimagess",method=RequestMethod.POST)
		public String portalimageadd(PortalImages portalimages,@RequestParam("portalImage")CommonsMultipartFile file,HttpSession session,Map<String,String> errMsg) throws Exception
		{
			
			//System.out.println("hii");
			Boolean flag=uService.portalimageUpload(portalimages, file, session);
				if(flag)
				{
					errMsg.put("errMsg","File Uploaded SuccessFully");
					System.out.println("done");
				}
				else
					errMsg.put("errMsg","File Not Uploaded");
			
			return "portalimage";
			
		}
		
		@RequestMapping(value="examschedule",method=RequestMethod.GET)
		public  String getAllExamSchdules(Map<String,List<ExamSchedule>> mapList)
		{
			List<ExamSchedule>eList=eDao.getAllExamSchdulesData();
			mapList.put("examList", eList);
		return "instexamschedule";
		}
}
