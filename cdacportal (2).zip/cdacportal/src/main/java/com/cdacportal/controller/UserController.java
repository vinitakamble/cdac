package com.cdacportal.controller;



import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.dao.UserDao;
import com.cdacportal.entity.Address;
import com.cdacportal.entity.CalendarEvents;
import com.cdacportal.entity.CdacBatches;
import com.cdacportal.entity.Course;
import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.Event;
import com.cdacportal.entity.PgDetails;
import com.cdacportal.entity.PlacedStudents;
import com.cdacportal.entity.PortalImages;
import com.cdacportal.entity.Result;
import com.cdacportal.entity.StudentPersonalDetails;
import com.cdacportal.entity.Subjects;
import com.cdacportal.entity.UserRegistration;
import com.cdacportal.entity.UserType;
import com.cdacportal.service.EncryptionService;
import com.cdacportal.service.UserService;

//Login and Registration controller



@Controller
public class UserController {
	
	
	/*ArrayList<Cities> cityList=new ArrayList<Cities>();*/
	@Autowired
	UserService uService;
	
	@Autowired
	UserDao dao;
	@Autowired
	EncryptionService eService;
	
	Map<String,String>calendarEvents;
	
	/**
	 * @author Tekchand
	 *
	 */
	/*
	 * This action for root controller and we will store list object into session 
	 * */
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String firstPage(Map<String,List<PortalImages>> mapList,HttpSession session)
	{
		
		List<PortalImages>list=portalImages();
		mapList.put("portalImage", list);
		
		List<CreateUser>listStud=getAllStudent();
		session.setAttribute("listStud", listStud);
		List<Event> eventsList= getAllEvents();
		session.setAttribute("eventsList", eventsList);
		return "index";
	}
	
	
/*	@RequestMapping(value="eventdescription",method=RequestMethod.GET)
	public String EventPage()
	{
		
		return "noticeboardinfo";
	}
	*/
	
	/* This code for Admin,Teacher registration */
	/**
	 * @author Tekchand
	 *
	 */
	@RequestMapping(value="regi")
	public String registration(UserRegistration userregi,UserType userType,Address address,@RequestParam("file_upload") CommonsMultipartFile file,HttpSession session,Map<String,String> errList) throws Exception
	{
		try
		{
			userregi.setUserType(userType);
			String password=eService.encrypt(userregi.getPassword());
			userregi.setPassword(password);
			uService.signup(userregi, address, file, session);
			
		  return "adminlogin";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		errList.put("errMsg", "User Not Register SuccessFully");
		return "signup";
	}
	
	
	/**
	 * @author Tekchand
	 *
	 */
	
	 /*
	  * This action for store personal detail
	  * */
	
	@RequestMapping(value="studentdetail",method=RequestMethod.POST)
	public String educationalDetails(StudentPersonalDetails spDetail,@RequestParam("student_id") int id,Map<String,String> errList) 
	{
		try
		{
			CreateUser c=new CreateUser();
			c.setId(id);
			spDetail.setCrUser(c);
			dao.savepersonalDetail(spDetail);
			return "educationdetail";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		errList.put("errMsg", "PersonalDetail Not Inserted");
		return "personalinfo";
	}
	

	/**
	 * @author Tekchand
	 *
	 */
	/* This code for Admin,Teacher Login and encrypted password using AES algo. */
	
	@RequestMapping(value="adminlogin",method=RequestMethod.POST)
	public String login(Map<String,List<UserRegistration>> map,Map<String,String> errMap,UserRegistration user,HttpServletRequest req) throws Exception
	{
	
		String password=eService.encrypt(user.getPassword());
		user.setPassword(password);
		List<UserRegistration> uLogin=uService.getUserData(user);
		
		
		
		for(UserRegistration userLogin:uLogin)
		{
			map.put("message", uLogin);
		   
			UserType uType =userLogin.getUserType();
			if(uType.getUserType().equals("admin"))
			{
				req.getSession().setAttribute("userName", userLogin);
				return "admin_after_login";
			}
			else if(uType.getUserType().equals("teacher"))
			{
				return "teacher_after_login";
			}
		}	
		errMap.put("errmsg", "UserName And Password Invalid");
	  return "adminlogin";
	}
	
	/**
	 * @author Tekchand
	 *
	 */
/*	This code for student login */
	
	@RequestMapping(value="studentlogin",method=RequestMethod.POST)
	public  String login(Map<String,List<CreateUser>> map,Map<String,String> errMap,CreateUser user,HttpServletRequest req) throws Exception
	{
		
		
		
		List<CreateUser> uLogin=uService.getUserStudentData(user);
		
		for(CreateUser userLogin:uLogin)
		{
			map.put("message", uLogin);
			req.getSession().setAttribute("rollNo", userLogin.getRollNo());
			req.getSession().setAttribute("student_id", userLogin.getId());
			
				return "student_after_login";
			
		}
	 
		errMap.put("errmsg", "UserName And Password Invalid");
		
	  return "studentlogin";
	}
	
	/**
	 * @author Nikita
	 *
	 */
	/* This Code for checking user exist or not */
	
	@RequestMapping(value="/validUser",method=RequestMethod.POST)
	public @ResponseBody String checkUser(@RequestParam("userName") String userName)
	{
		
		boolean user=uService.validUser(userName);
		String u=""+user;
		return u;
	}
	
	/**
	 * @author Vivek
	 *
	 */
	/* This Code for Check email exist or not */
	
	@RequestMapping(value="/validEmail",method=RequestMethod.POST)
	public @ResponseBody String checkEmail(@RequestParam("emailId") String emailId)
	{
		
		boolean email=uService.validEmail(emailId);
		String e=""+email;
		return e;
	}
	
	/**
	 * @author Hitali
	 *
	 */
	
	/*	This code for Change Password for Student and trigger for store the backup of old password */
	
	@RequestMapping(value="/changePassword",method=RequestMethod.POST)
	public @ResponseBody String changePassword(@RequestParam("userName") String userName,@RequestParam("oldPassword") String oldPassword,@RequestParam("newPassword") String newPassword,@RequestParam("action") Boolean action)
	{
		String msg=uService.changeUserPassword(userName,oldPassword,newPassword,action);	
		return msg;
	}
	
	/**
	 * @author Hitali
	 *
	 */
		/*
		 * This code for Add event on Notice Board
		 * */
	
	@RequestMapping(value="/eventcontroller", method=RequestMethod.POST)
	public @ResponseBody String event(@RequestParam("event_name") String event_name, @RequestParam("event_date") String event_date, @RequestParam("event_description") String event_description)
	{
		try
		{
			com.cdacportal.entity.Event event = new com.cdacportal.entity.Event();
			event.setEvent_date(event_date);
			event.setEvent_name(event_name);
			event.setEvent_description(event_description);
			
			dao.save(event);
			return "event add successfully";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	return "Event Not Added ";
		
	}
	
	/**
	 * @author Tekchand
	 *
	 */
	 /* This code for Add Calendar Events */
	@RequestMapping(value="/event",method=RequestMethod.POST)
	public String insertCalendarEvent(CalendarEvents cEvent,Map<String,String>errMsg,HttpServletRequest req)
	{
		try
		{
			dao.save(cEvent);
			errMsg.put("errMsg","Calendar Event Added");
			
			calendarEvents=getAllCalendarEvents();
			req.getSession().setAttribute("calendarEvents", calendarEvents);
		  return "calendarevent";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		errMsg.put("errMsg","Calendar Event Not Added");
	  return "calendarevent";
	}
	
	/**
	 * @author Tekchand
	 *
	 */
	/*
	 * This method for get all portal images
	 * */
	public  List<PortalImages> portalImages()
	{
		List<PortalImages>pList=dao.getAllPortalImages();
	
		return pList;
	}
	/**
	 * @author Tekchand
	 *
	 */
	/*
	 * This Method for get all Students
	 * */
	public  List<CreateUser> getAllStudent()
	{
		List<CreateUser>pList=dao.getAllStudentData();
	
		return pList;
	}
	
	/**
	 * @author Hitali
	 *
	 */
	/*
	 * This code for get all Notice board events
	 * */
	public  List<Event> getAllEvents()
	{
		List<Event>pList=dao.getAllEventsData();
	
		return pList;
	}
	
	
	/**
	 * @author Tekchand
	 *
	 */
	/*
	 * This Method for get all Calendar events
	 * */
	public Map<String,String> getAllCalendarEvents()
	{
		Map<String,String>calendarEvents=dao.getAllCalendarEventsData();
	
		return calendarEvents;
	}
	
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String sessionDestroy(@RequestParam("out")boolean out,HttpServletRequest req)
	{
		
		req.getSession().removeAttribute("listStud");
		req.getSession().removeAttribute("eventsList");
		req.getSession().removeAttribute("calendarEvents");
		req.getSession().removeAttribute("userName");   
		req.getSession().removeAttribute("rollNo");
		
		req.getSession().invalidate();
			
				if(out)
					return "studentlogin";
				else
				    return "adminlogin";
			
		
	}
	
	@RequestMapping(value="/personalinfo",method=RequestMethod.GET)
	public String personalInfo(@RequestParam("rollNo")String rollNo,Map<String,StudentPersonalDetails>mapList)
	{
				CreateUser c=new CreateUser();
				c.setRollNo(rollNo);
			
				List<StudentPersonalDetails> per=dao.getStudPersonalInfo(c);
				for(StudentPersonalDetails cUser:per)
				{
					System.out.println(cUser.getfName());
					mapList.put("cUser", cUser);
				}
		return "personalinfo";
	}
	

	
	@RequestMapping(value="/savePlacement",method=RequestMethod.POST)
	public String studPlacementSave(PlacedStudents p,Map<String,List<CreateUser>> cList,@RequestParam("batch_id")int batch_id,Map<String,String> errMsg,Map<String,List<CdacBatches>> batchList) 
	{
			try
			{
				CdacBatches cd=new CdacBatches();
				cd.setId(batch_id);
			    p.setBatch(cd);
				dao.save(p);
				List<CreateUser>listStud=getAllStudent();
				cList.put("message", listStud);
				List<CdacBatches> batches=getAllBatches();
				batchList.put("batchlist", batches);
				errMsg.put("errMsg","Data Inserted SuccessFully");
			  return "RecruitedStudentsadd";
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		 errMsg.put("errMsg","Data Not Inserted");
		return "RecruitedStudentsadd";
	}
	
	private List<Course> getAllCourse() {
		List<Course> cdacList=dao.getCourses();
		return cdacList;
	}
	
	
	@RequestMapping(value="/RecruitedStudentsadd",method=RequestMethod.GET)
	public String fetchRecruitedStudentsadd(Map<String,List<CreateUser>> cList,Map<String,List<CdacBatches>> batchList,Map<String,List<Course>>coList) 
	{
		
		List<CreateUser>listStud=getAllStudent();
		cList.put("message", listStud);
		
		List<Course>courseList=getAllCourse();
		coList.put("courseList", courseList);
		List<CdacBatches> batches=getAllBatches();
		batchList.put("batchlist", batches);
		return "RecruitedStudentsadd";
	}

	
	
	
	
	private List<CdacBatches> getAllBatches() {
		List<CdacBatches> cdacList=dao.getBatches();
		return cdacList;
	}
	
	
	@RequestMapping(value="/fetchpgdetails",method=RequestMethod.GET)
	public String pgdetails(Map<String,List<PgDetails>> placeList) 
	{
		List<PgDetails> pl =pgDetails();
		placeList.put("placeList", pl);
		return "pgdetails";
		
	}
	
	@RequestMapping(value="/pgdetailspage",method=RequestMethod.GET)
	public String pgdetails() 
	{
		
		return "uploadpgdetails";
		
	}
	
	@RequestMapping(value="instiCalendar",method=RequestMethod.GET)
	public String calendarpage(HttpServletRequest req)
	{
		HttpSession session=req.getSession();	
		calendarEvents=getAllCalendarEvents();
		session.setAttribute("calendarEvents", calendarEvents);
		return "InstitituteCalendar";
	}
	
	
	
	public  List<PgDetails> pgDetails()
	{
		List<PgDetails>pList=dao.getAllpgdetails();
	
		return pList;
	}
	
	public  List<Subjects> getAllSubjects()
	{
		List<Subjects>sList=dao.getAllSubjectsList();
	
		return sList;
	}
	
	@RequestMapping(value="pgdetails",method=RequestMethod.POST)
	  public String pgdetails(PgDetails pg ,Map<String,String> errList) 
	{
		try
		  {
			 
			  dao.save(pg);
		  	  errList.put("errMsg", "record Registered SuccessFully");
		     return "uploadpgdetails";
		  }
		  catch (Exception e) 
		  {
			e.printStackTrace();
		  }
		  errList.put("errMsg", "record Not Registered ");
		  return "uploadpgdetails";
			
	}
	
	@RequestMapping(value="/fetchPlacementList",method=RequestMethod.GET)
	public String fetchPlacedList(HttpServletRequest req) {
		
		List<PlacedStudents> list=dao.fetchPlacmentRecords(req.getParameter("batch"));
		List<CdacBatches> cdacList=dao.getBatch(req.getParameter("batch"));
		HttpSession session=req.getSession();
		session.setAttribute("PlacedStudList", list);
		session.setAttribute("cdacList", cdacList);
		return "placementstudentlist";
	}
	
	
	
	@RequestMapping(value="/placementsdetail",method=RequestMethod.GET)
	public String fetchBatchList(HttpServletRequest req) {
		
		
		List<CdacBatches> cdacList=dao.getBatches();
		HttpSession session=req.getSession();
		
		session.setAttribute("cdacList", cdacList);
		return "placements";
	}
	
	
	@RequestMapping(value="/resultAction",method=RequestMethod.GET)
	public String resultPageAction(HttpSession session) {
		
		List<CreateUser>studentList=getAllStudent();
		List<Course>courseList=getAllCourse();
		List<Subjects>subjectList= getAllSubjects();
		session.setAttribute("subjectList", subjectList);
		session.setAttribute("courseList", courseList);
		session.setAttribute("studentList", studentList);
		
		return "studentresult";
	}
	
	
	
	@RequestMapping(value="/searchResultAtction",method=RequestMethod.GET)
	public String searchResultPageAction(HttpSession session) 
	{
		
		List<CreateUser>studentList=getAllStudent();
		List<Course>courseList=getAllCourse();
		List<Subjects>subjectList= getAllSubjects();
		session.setAttribute("subjectList", subjectList);
		session.setAttribute("courseList", courseList);
		session.setAttribute("studentList", studentList);
		
		return "result";
	}
	
	@RequestMapping(value="searchResult",method=RequestMethod.POST)
	@ResponseBody
	public  Result searchResultPageAction(HttpSession session,
			 @RequestParam("subject")int subject
			,@RequestParam("rollNo")int rollNo
			,@RequestParam("course")int course) 
	{
		
			List<CreateUser>studentList=getAllStudent();
			List<Course>courseList=getAllCourse();
			List<Subjects>subjectList= getAllSubjects();
			List<Result> resultList=dao.getResult(subject,rollNo,course);
			session.setAttribute("subjectList", subjectList);
			session.setAttribute("courseList", courseList);
			session.setAttribute("studentList", studentList);
			System.out.println(rollNo);
			
		return resultList.get(0);
	}
	
	@RequestMapping(value="/examscheduleAction",method=RequestMethod.GET)
	public String examscheduleAction()
	{
		return "examschedule";
	}
	
	@RequestMapping(value="/UploadSyllabusAction",method=RequestMethod.GET)
	public String uploadSyllabusAction()
	{
		return "UploadSyllabus";
	}
	
	@RequestMapping(value="/portalimageAction",method=RequestMethod.GET)
	public String portalimageAction()
	{
		return "portalimage";
	}
	
	@RequestMapping(value="/eventAction",method=RequestMethod.GET)
	public String eventAction()
	{
		return "event";
	}
	
	@RequestMapping(value="/calendareventAction",method=RequestMethod.GET)
	public String calendareventAction()
	{
		return "calendarevent";
	}
	
	@RequestMapping(value="/student_regi_by_adminAction",method=RequestMethod.GET)
	public String student_regi_by_adminAction()
	{
		return "student_regi_by_admin";
	}
	
	@RequestMapping(value="/studyMaterialAction",method=RequestMethod.GET)
	public String studyMaterialAction()
	{
		return "studyMaterial";
	}
	
	@RequestMapping(value="/contactusAction",method=RequestMethod.GET)
	public String contactusAction()
	{
		return "contactus";
	}
	
	@RequestMapping(value="/educationdetailAction",method=RequestMethod.GET)
	public String educationdetailAction()
	{
		return "educationdetail";
	}
	
	@RequestMapping(value="/attachmentsAction",method=RequestMethod.GET)
	public String attachmentsAction()
	{
		return "attachments";
	}
	
	@RequestMapping(value="/studentattendanceAction",method=RequestMethod.GET)
	public String studentattendanceAction()
	{
		return "studentattendance";
	}
	
	@RequestMapping(value="/canteenformAction",method=RequestMethod.GET)
	public String canteenformAction()
	{
		return "canteenform";
	}
	
	@RequestMapping(value="/syllabusAction",method=RequestMethod.GET)
	public String syllabusAction()
	{
		return "syllabus";
	}
	
	@RequestMapping(value="/adminloginAction",method=RequestMethod.GET)
	public String adminloginAction()
	{
		return "adminlogin";
	}
	
	@RequestMapping(value="/signupAction",method=RequestMethod.GET)
	public String signupAction()
	{
		return "signup";
	}
	
}
