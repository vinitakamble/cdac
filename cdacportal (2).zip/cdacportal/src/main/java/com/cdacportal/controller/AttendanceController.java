package com.cdacportal.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cdacportal.entity.Attendance;
import com.cdacportal.service.UserService;


@Controller
public class AttendanceController {

	@Autowired
	UserService uService;
	
	
	
	@RequestMapping(value="attendance",method=RequestMethod.GET)
	public String getStudentAtt(Map<String,List<Attendance>> map)
	{
		 List<Attendance> att=uService.getUserAttendance();
		 map.put("attendance", att);
		
		 return "attendance";
	}
	
	/*@RequestMapping(value="/uploadattendance.page",method=RequestMethod.POST)
	public void uploadAttendance(@RequestParam("file") CommonsMultipartFile file,@RequestParam("attendanceDate") String attendanceDate,@RequestParam("id") int id,HttpSession session) throws Exception
	{
		
		uService.uploadExcel(file, attendanceDate,id, session);
	}*/
	
	@RequestMapping(value="createuser",method=RequestMethod.POST)
	public String userRegiFromAdmin(@RequestParam("file") CommonsMultipartFile file,HttpSession session,Map<String,String>errMsg) throws Exception
	{
		try
		{			
		    uService.uploadExcelUser(file, session);
			errMsg.put("errMsg", "Excel Uploaded SuccessFully");
		  return "student_regi_by_admin";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
			errMsg.put("errMsg", "Excel Not Uploaded");
		return "student_regi_by_admin";
	}
	
	
	
}
