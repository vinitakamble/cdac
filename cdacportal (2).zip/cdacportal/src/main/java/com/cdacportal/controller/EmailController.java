package com.cdacportal.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cdacportal.dao.UserDao;
import com.cdacportal.entity.Course;
import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.PlacedStudents;
import com.cdacportal.entity.Result;
import com.cdacportal.entity.Subjects;
import com.cdacportal.service.EmailService;

@Controller
public class EmailController {

	@Autowired
	private EmailService eService;
	
	@Autowired
	UserDao uDao;
	
	@RequestMapping(value="EmailService",method=RequestMethod.POST)
	public @ResponseBody String sendEmail(@RequestParam("mailTo")String mailTo,@RequestParam("subject") String subject,@RequestParam("message") String message)
	{
	
		return eService.sendEmail(mailTo,subject,message);
	}
	

	@RequestMapping(value="/studentloginpage",method=RequestMethod.GET)
	public String studentLogin()
	{
		
			return "studentlogin";
	}
	
	

	
	
	
	@RequestMapping(value="/result",method=RequestMethod.POST)
	private String insertResult(Result res,Map<String,String> errMsg,@RequestParam("student")int student_id,@RequestParam("course")int course_id,@RequestParam("subject")int subject_id)
	{
		try
		{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-dd-MM");
			Date d=new Date();
			res.setUploaded_date(sdf.format(d));
			System.out.println(student_id+" "+subject_id+" "+course_id);
			CreateUser c=new CreateUser();
			c.setId(student_id);
		    Subjects sub=new Subjects();
			sub.setId(subject_id);
		
			Course course=new Course();
			course.setId(course_id);
			
		res.setCourse_id(course);
		res.setSubject_id(sub);
		res.setStudent_id(c);
		uDao.save(res);
			errMsg.put("errMsg","Result Added SuccessFully");
			return "studentresult";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		errMsg.put("errMsg","Result Not Added ");
		return "studentresult";
	}
}
