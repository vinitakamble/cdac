package com.cdacportal.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cdacportal.dao.UserDao;
import com.cdacportal.entity.Canteen;
import com.cdacportal.entity.CreateUser;




@Controller
public class CanteenFormController {
  
  @Autowired
  private UserDao uDao;
  
  

  @RequestMapping(value = "canteen", method = RequestMethod.POST)
  public String canteenpage(Canteen c,@RequestParam("studentt_id") int id,Map<String,String> errList) 
  {
	  try
	  {
		  CreateUser cu=new CreateUser();
	  	  cu.setId(id);
	  	  c.setStudent_id(cu);
	  	  uDao.save(c);
	  	  errList.put("errMsg", "Canteen Registered SuccessFully");
	     return "canteenform";
	  }
	  catch (Exception e) 
	  {
		e.printStackTrace();
	  }
	  errList.put("errMsg", "Canteen Not Registered ");
	  return "canteenform";
  }
}
