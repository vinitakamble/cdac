package com.cdacportal.entity;




import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_student_result")
public class Result
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private int marks;
	private int outofmarks;
	private String uploaded_date;
	
	@ManyToOne
	private Subjects subject_id;
	
	@ManyToOne
	private Course course_id;
	
	@ManyToOne
	@JoinColumn(name="student_id")
	private CreateUser student_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getOutofmarks() {
		return outofmarks;
	}

	public void setOutofmarks(int outofmarks) {
		this.outofmarks = outofmarks;
	}

	
	public String getUploaded_date() {
		return uploaded_date;
	}

	public void setUploaded_date(String uploaded_date) {
		this.uploaded_date = uploaded_date;
	}

	public CreateUser getStudent_id() {
		return student_id;
	}

	public void setStudent_id(CreateUser student_id) {
		this.student_id = student_id;
	}

	public Subjects getSubject_id() {
		return subject_id;
	}

	public void setSubject_id(Subjects subject_id) {
		this.subject_id = subject_id;
	}

	public Course getCourse_id() {
		return course_id;
	}

	public void setCourse_id(Course course_id) {
		this.course_id = course_id;
	}

	@Override
	public String toString() {
		return "Result [id=" + id + ", marks=" + marks + ", outofmarks=" + outofmarks + ", uploaded_date="
				+ uploaded_date + ", subject_id=" + subject_id + ", course_id=" + course_id + ", student_id="
				+ student_id + "]";
	}

	
	

	
	
}
