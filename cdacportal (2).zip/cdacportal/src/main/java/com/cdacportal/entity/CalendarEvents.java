package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cdac_calender_event")
public class CalendarEvents {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String events_Date;
	private String event_Name;
	private String event_description;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEvents_Date() {
		return events_Date;
	}
	public void setEvents_Date(String events_Date) {
		this.events_Date = events_Date;
	}
	public String getEvent_Name() {
		return event_Name;
	}
	public void setEvent_Name(String event_Name) {
		this.event_Name = event_Name;
	}
	public String getEvent_description() {
		return event_description;
	}
	public void setEvent_description(String event_description) {
		this.event_description = event_description;
	}
	

	}
