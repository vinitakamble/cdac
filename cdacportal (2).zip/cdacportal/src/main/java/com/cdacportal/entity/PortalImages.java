package com.cdacportal.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="cdac_portalimage",uniqueConstraints=@UniqueConstraint(columnNames={"image"}))
public class PortalImages

{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String image;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
}
