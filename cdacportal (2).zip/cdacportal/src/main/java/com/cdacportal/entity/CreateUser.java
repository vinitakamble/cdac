package com.cdacportal.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="cdac_user",uniqueConstraints=@UniqueConstraint(columnNames= {"rollNo","formNo"}))
public class CreateUser {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	private String rollNo;
	private String password;
	
	private String formNo; 
	private String uploadDate;
	private String emailId;
	@OneToOne
	private UploadAttachment uAttach;
	
	@OneToMany
	private Set<Canteen> canteen;
	
	@OneToOne
	private EducationDetail education;
	
	@OneToMany
	private Set<Attendance> attendance;
	
	@OneToOne
    private StudentPersonalDetails student;
	
	public StudentPersonalDetails getStudent() {
		return student;
	}
	public void setStudent(StudentPersonalDetails student) {
		this.student = student;
	}
	public Set<Attendance> getAttendance() {
		return attendance;
	}
	public void setAttendance(Set<Attendance> attendance) {
		this.attendance = attendance;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFormNo() {
		return formNo;
	}
	public void setFormNo(String formNo) {
		this.formNo = formNo;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public UploadAttachment getuAttach() {
		return uAttach;
	}
	public void setuAttach(UploadAttachment uAttach) {
		this.uAttach = uAttach;
	}
	public EducationDetail getEducation() {
		return education;
	}
	public void setEducation(EducationDetail education) {
		this.education = education;
	}
	public Set<Canteen> getCanteen() {
		return canteen;
	}
	public void setCanteen(Set<Canteen> canteen) {
		this.canteen = canteen;
	}
	
}
