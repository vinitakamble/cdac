package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_placed_students")
public class PlacedStudents {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;	
	private String Student_Name;
	private String Course;
	private String Recruiter;
	private String RollNo;
	
	 @ManyToOne
	 @JoinColumn(name="batch") 
	 private CdacBatches batch;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStudent_Name() {
		return Student_Name;
	}

	public void setStudent_Name(String student_Name) {
		Student_Name = student_Name;
	}

	public String getCourse() {
		return Course;
	}

	public void setCourse(String course) {
		Course = course;
	}

	public String getRecruiter() {
		return Recruiter;
	}

	public void setRecruiter(String recruiter) {
		Recruiter = recruiter;
	}

	public String getRollNo() {
		return RollNo;
	}

	public void setRollNo(String rollNo) {
		RollNo = rollNo;
	}

	public CdacBatches getBatch() {
		return batch;
	}

	public void setBatch(CdacBatches batch) {
		this.batch = batch;
	}

	 
	
	
}
