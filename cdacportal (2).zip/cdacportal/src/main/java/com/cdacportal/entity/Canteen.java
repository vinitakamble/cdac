package com.cdacportal.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;




@Entity
@Table(name="cdac_canteen")

public class Canteen {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	private String canteenpackage;
    
	private String fromdate;
    private String todate;
	
    private String amount;
    
    @ManyToOne
    @JoinColumn(name="student_id")
    private CreateUser student_id;
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCanteenpackage() {
		return canteenpackage;
	}

	public void setCanteenpackage(String canteenpackage) {
		this.canteenpackage = canteenpackage;
	}

	public String getFromdate() {
		return fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public CreateUser getStudent_id() {
		return student_id;
	}

	public void setStudent_id(CreateUser student_id) {
		this.student_id = student_id;
	}

	
}
