package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name="cdac_student_upload_attachment")
public class UploadAttachment
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String tenupload;
	private String twelveupload;
	private String diploma;
	private String photo;
	private String signature;
	private String degree;
	
	@OneToOne
	private CreateUser student_id;
	
	public CreateUser getStudent_id() {
		return student_id;
	}

	public void setStudent_id(CreateUser student_id) {
		this.student_id = student_id;
	}
	
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public String getTenupload() {
		return tenupload;
	}
	public void setTenupload(String tenupload) {
		this.tenupload = tenupload;
	}
	public String getTwelveupload() {
		return twelveupload;
	}
	public void setTwelveupload(String twelveupload) {
		this.twelveupload = twelveupload;
	}
	public String getDiploma() {
		return diploma;
	}
	public void setDiploma(String diploma) {
		this.diploma = diploma;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	
	
}
