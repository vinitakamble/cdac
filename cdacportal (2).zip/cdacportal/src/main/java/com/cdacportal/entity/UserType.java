package com.cdacportal.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_usertype")
public class UserType 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String userType;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="userType")
	private Set<UserRegistration> user;

	
	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getUserType() 
	{
		return userType;
	}

	public void setUserType(String userType) 
	{
		this.userType = userType;
	}

	public Set<UserRegistration> getUser() {
		return user;
	}

	public void setUser(Set<UserRegistration> user) {
		this.user = user;
	}

	
}
