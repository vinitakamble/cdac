package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_user_address")
public class Address
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String city;
	private String state;
	private String pincode;
	private String street;
	private String landMark;
	private String houseNumber;
	private String flatNo;
	
	
	
	@OneToOne    // This is for one to one  mapping between UserRegistration and Address
	@MapsId  // Foreign key relation in Address
	private UserRegistration userregistration;

	public int getId() 
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getCity() 
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getState() 
	{
		return state;
	}

	public void setState(String state) 
	{
		this.state = state;
	}

	public String getPincode() 
	{
		return pincode;
	}

	public void setPincode(String pincode)
	{
		this.pincode = pincode;
	}

	public String getStreet() 
	{
		return street;
	}

	public void setStreet(String street)
	{
		this.street = street;
	}

	public String getLandMark()
	{
		return landMark;
	}

	public void setLandMark(String landMark) 
	{
		this.landMark = landMark;
	}

	public String getHouseNumber() 
	{
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) 
	{
		this.houseNumber = houseNumber;
	}

	public String getFlatNo() 
	{
		return flatNo;
	}

	public void setFlatNo(String flatNo) 
	{
		this.flatNo = flatNo;
	}

	public UserRegistration getUserregistration()
	{
		return userregistration;
	}

	public void setUserregistration(UserRegistration userregistration)
	{
		this.userregistration = userregistration;
	}
	
}
