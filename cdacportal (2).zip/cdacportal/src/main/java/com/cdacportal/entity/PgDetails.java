package com.cdacportal.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cdac_pgdetails")
public class PgDetails
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String broker_name;
	private String broker_mob_no;
	private String location;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBroker_name() {
		return broker_name;
	}
	public void setBroker_name(String broker_name) {
		this.broker_name = broker_name;
	}
	public String getBroker_mob_no() {
		return broker_mob_no;
	}
	public void setBroker_mob_no(String broker_mob_no) {
		this.broker_mob_no = broker_mob_no;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
}
