package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cdac_attendance")
public class Attendance 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private String attendanceDate;
	
	private String attendanceType;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private CreateUser crUser;
	
	@ManyToOne
	@JoinColumn(name="lectureTime")
	private LectureTime lectureTime;

	public CreateUser getCrUser() {
		return crUser;
	}

	public void setCrUser(CreateUser crUser) {
		this.crUser = crUser;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(String attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public String getAttendanceType() {
		return attendanceType;
	}

	public void setAttendanceType(String attendanceType) {
		this.attendanceType = attendanceType;
	}


	public LectureTime getLectureTime() {
		return lectureTime;
	}

	public void setLectureTime(LectureTime lectureTime) {
		this.lectureTime = lectureTime;
	}
	
}
