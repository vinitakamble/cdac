package com.cdacportal.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "Cdac_UploadStudyMaterial",uniqueConstraints=@UniqueConstraint(columnNames={"subjectName","filePath"}))
public class StudyMaterial {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String batchyear;
	private String subjectName;
    private String filePath;
    
    
    
	
  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getBatchyear() {
		return batchyear;
	}
	public void setBatchyear(String batchyear) {
		this.batchyear = batchyear;
	}
	

   
}
