package com.cdacportal.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="cdac_personaldetails",uniqueConstraints=@UniqueConstraint(columnNames={"emailId"}))
public class StudentPersonalDetails 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String fName;
	private String mName;
	private String lName;
	private String emailId;
	private String gender;
	private String mobNo;
	private String fatherNo;
	private String permantAddress;
	private String correspondingAddress;
	private String crrstate;
	private String crrcity;
	private String percity;
	private String perstate;
	
	@OneToOne
	private CreateUser crUser;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFatherNo() {
		return fatherNo;
	}

	public void setFatherNo(String fatherNo) {
		this.fatherNo = fatherNo;
	}

	public String getCrrstate() {
		return crrstate;
	}

	public void setCrrstate(String crrstate) {
		this.crrstate = crrstate;
	}

	public String getCrrcity() {
		return crrcity;
	}

	public void setCrrcity(String crrcity) {
		this.crrcity = crrcity;
	}

	public String getPercity() {
		return percity;
	}

	public void setPercity(String percity) {
		this.percity = percity;
	}

	public String getPerstate() {
		return perstate;
	}

	public void setPerstate(String perstate) {
		this.perstate = perstate;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getPermantAddress() {
		return permantAddress;
	}

	public void setPermantAddress(String permantAddress) {
		this.permantAddress = permantAddress;
	}

	public String getCorrespondingAddress() {
		return correspondingAddress;
	}

	public void setCorrespondingAddress(String correspondingAddress) {
		this.correspondingAddress = correspondingAddress;
	}

	
	public CreateUser getCrUser() {
		return crUser;
	}

	public void setCrUser(CreateUser crUser) {
		this.crUser = crUser;
	}
	
	
	
}
