package com.cdacportal.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="cdac_batches",uniqueConstraints=@UniqueConstraint(columnNames={"batch","course"}))
public class CdacBatches {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String batch;
	private String recruited_percent;
	private String Max_Package;
	private String Avg_Package;
	private String course;
	@OneToMany
	private Set<PlacedStudents> placed_student;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getRecruited_percent() {
		return recruited_percent;
	}

	public void setRecruited_percent(String recruited_percent) {
		this.recruited_percent = recruited_percent;
	}

	public String getMax_Package() {
		return Max_Package;
	}

	public void setMax_Package(String max_Package) {
		Max_Package = max_Package;
	}

	public String getAvg_Package() {
		return Avg_Package;
	}

	public void setAvg_Package(String avg_Package) {
		Avg_Package = avg_Package;
	}

	public Set<PlacedStudents> getPlaced_student() {
		return placed_student;
	}
	
	
	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public void setPlaced_student(Set<PlacedStudents> placed_student) {
		this.placed_student = placed_student;
	}

	@Override
	public String toString() {
		return "CdacBatches [id=" + id + ", batch=" + batch + ", recruited_percent=" + recruited_percent
				+ ", Max_Package=" + Max_Package + ", Avg_Package=" + Avg_Package + ", placed_student=" + placed_student
				+ "]";
	}
	 
	

}
	
	


