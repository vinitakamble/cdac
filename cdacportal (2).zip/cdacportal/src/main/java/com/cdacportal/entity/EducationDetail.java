package com.cdacportal.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="cdac_education_detail")
public class EducationDetail
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int  tenObtainMarks;
	private int tenTotalMarks;
	private double tenPercentage;
	private int twelveObtainMarks;
	private int twelveTotalMarks;
	private double twelvePercentage;
	private int DObtainMarks;
	private int DTotalMarks;
	private double DPercentage;
	private String gDegree;
	private String gStream;
	private int gObtainMarks;
	private int gTotalMarks;
	private double gPercentage;
	
	@OneToOne
	private CreateUser student_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTenObtainMarks() {
		return tenObtainMarks;
	}

	public void setTenObtainMarks(int tenObtainMarks) {
		this.tenObtainMarks = tenObtainMarks;
	}

	public int getTenTotalMarks() {
		return tenTotalMarks;
	}

	public void setTenTotalMarks(int tenTotalMarks) {
		this.tenTotalMarks = tenTotalMarks;
	}

	public double getTenPercentage() {
		return tenPercentage;
	}

	public void setTenPercentage(double tenPercentage) {
		this.tenPercentage = tenPercentage;
	}

	public int getTwelveObtainMarks() {
		return twelveObtainMarks;
	}

	public void setTwelveObtainMarks(int twelveObtainMarks) {
		this.twelveObtainMarks = twelveObtainMarks;
	}

	public int getTwelveTotalMarks() {
		return twelveTotalMarks;
	}

	public void setTwelveTotalMarks(int twelveTotalMarks) {
		this.twelveTotalMarks = twelveTotalMarks;
	}

	public double getTwelvePercentage() {
		return twelvePercentage;
	}

	public void setTwelvePercentage(double twelvePercentage) {
		this.twelvePercentage = twelvePercentage;
	}

	public int getDObtainMarks() {
		return DObtainMarks;
	}

	public void setDObtainMarks(int dObtainMarks) {
		DObtainMarks = dObtainMarks;
	}

	public int getDTotalMarks() {
		return DTotalMarks;
	}

	public void setDTotalMarks(int dTotalMarks) {
		DTotalMarks = dTotalMarks;
	}

	public double getDPercentage() {
		return DPercentage;
	}

	public void setDPercentage(double dPercentage) {
		DPercentage = dPercentage;
	}

	public String getgDegree() {
		return gDegree;
	}

	public void setgDegree(String gDegree) {
		this.gDegree = gDegree;
	}

	public String getgStream() {
		return gStream;
	}

	public void setgStream(String gStream) {
		this.gStream = gStream;
	}

	public int getgObtainMarks() {
		return gObtainMarks;
	}

	public void setgObtainMarks(int gObtainMarks) {
		this.gObtainMarks = gObtainMarks;
	}

	public int getgTotalMarks() {
		return gTotalMarks;
	}

	public void setgTotalMarks(int gTotalMarks) {
		this.gTotalMarks = gTotalMarks;
	}

	public double getgPercentage() {
		return gPercentage;
	}

	public void setgPercentage(double gPercentage) {
		this.gPercentage = gPercentage;
	}

	public CreateUser getStudent_id() {
		return student_id;
	}

	public void setStudent_id(CreateUser student_id) {
		this.student_id = student_id;
	}

	

	
	
	
	
}
