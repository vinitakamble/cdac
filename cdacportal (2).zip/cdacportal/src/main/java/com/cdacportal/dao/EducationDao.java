package com.cdacportal.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.ExamSchedule;

@Component
public class EducationDao
{
	@PersistenceContext
	EntityManager em;
	
	@Transactional
	public void saveEducation(Object o)
	{
		em.persist(o);
	}

	public List<ExamSchedule> getAllExamSchdulesData()
	{
		String sql="from ExamSchedule";
		TypedQuery<ExamSchedule> query=(TypedQuery<ExamSchedule>)em.createQuery(sql);
			List<ExamSchedule> usersList=query.getResultList();
		return usersList;
	}	
}
