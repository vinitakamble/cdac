package com.cdacportal.dao;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cdacportal.entity.Attendance;
import com.cdacportal.entity.CalendarEvents;
import com.cdacportal.entity.CdacBatches;
import com.cdacportal.entity.Course;
import com.cdacportal.entity.CreateUser;
import com.cdacportal.entity.Event;
import com.cdacportal.entity.PgDetails;
import com.cdacportal.entity.PlacedStudents;
import com.cdacportal.entity.PortalImages;
import com.cdacportal.entity.Result;
import com.cdacportal.entity.StudentPersonalDetails;
import com.cdacportal.entity.StudyMaterial;
import com.cdacportal.entity.Subjects;
import com.cdacportal.entity.Syllabus;
import com.cdacportal.entity.UserRegistration;


@Component
public class UserDao 
{
	
	@PersistenceContext
	private EntityManager em;
	
	
	@Transactional
	public void savepersonalDetail(StudentPersonalDetails spDetail)
	{
		try {
			em.persist(spDetail);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/* This code for Register User In DataBase */
	
	
	
	
	
	
	/*@Transactional
	public List<Cities> getAllCities()
	{
		
		List<Cities> stList = null;
		try
		{
			TypedQuery<Cities> stQuery=(TypedQuery<Cities>)em.createQuery("from Cities");
			stList=stQuery.getResultList();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	  
	   return stList;
	}
	*/
	@Transactional
	public void save(Object obj)
	{
		em.merge(obj);
		System.out.println(obj.toString());
	}
	
	/* This code for Admin,Teacher UserName Exist Or Not */
	
	@Transactional
	public boolean getUserName(String userName)
	{
		 String query="from UserRegistration where userName='"+userName+"'";
		TypedQuery<UserRegistration> q=(TypedQuery<UserRegistration>) em.createQuery(query);
		List<UserRegistration> e= (List<UserRegistration>) q.getResultList();
		
		 for(UserRegistration u:e)
		 {
			 if(u.getUserName().equals(userName))
			 {
				 return true;
			 }
		 }
			return false;
	}
	
	/* This code for Admin,Teacher user Exist Or Not */
	
	@Transactional
	public List<UserRegistration> getUser(UserRegistration user)
	{
		 String query="from UserRegistration where userName='"+user.getUserName()+"'and password='"+user.getPassword()+"'";
		TypedQuery<UserRegistration> q=(TypedQuery<UserRegistration>) em.createQuery(query);
		List<UserRegistration> e= (List<UserRegistration>) q.getResultList();
		return e;
	}
	
	/*This code for all student attendance
	*/
	@Transactional
	public List<Attendance> getAllStudentAttendance()
	{
		
		String sql="from Attendance";
		TypedQuery<Attendance> q=(TypedQuery<Attendance>)em.createQuery(sql);
			List<Attendance> e=q.getResultList();
		return e;
	}
	
	
	@Transactional
	public List<Syllabus> getAllSyllabus()
	{
		
		String sql="from Syllabus";
		TypedQuery<Syllabus> q=(TypedQuery<Syllabus>)em.createQuery(sql);
			List<Syllabus> e=q.getResultList();
		return e;
	}
	
	
	@Transactional
	public List<StudyMaterial> getAllStudyMaterial()
	{
		
		String sql="from StudyMaterial";
		TypedQuery<StudyMaterial> q=(TypedQuery<StudyMaterial>)em.createQuery(sql);
			List<StudyMaterial> e=q.getResultList();
		return e;
	}
	
	
	/* This code for Find Student Attendance */
	@Transactional
	public List<Attendance> getAtt(int id)
	{
		
		String sql="from Attendance a where "
				+ "a.userRegi='"+id+"'";
		TypedQuery<Attendance> q=(TypedQuery<Attendance>)em.createQuery(sql);
			List<Attendance> e=q.getResultList();
		return e;
	}
	
	/* This code for Student attendance Upload */
	
	@Transactional
	public void uploadUserAtt(Attendance a)
	{
		em.persist(a);
	}
	
	/* This code for Student Registration by admin user uploading excel file */
	
	@Transactional
	public void createUser(CreateUser user)
	{
		em.persist(user);
	}

	/* This code for Student Exist Or Not */
	
	public List<CreateUser> getStudent(CreateUser user) {
		 
		    String query="from CreateUser where rollNo='"+user.getRollNo()+"'and password='"+user.getPassword()+"'";
			TypedQuery<CreateUser> q=(TypedQuery<CreateUser>) em.createQuery(query);
			List<CreateUser> e= (List<CreateUser>) q.getResultList();
			
		return e;
	}
	
	
	
	
	
	
	
	
	
	
	public List<StudentPersonalDetails> getStudentPersonalInfo(List<CreateUser> user)
	{
		 
	    String query="from StudentPersonalDetails where id='"+user.get(0).getId()+"'";
		TypedQuery<StudentPersonalDetails> q=(TypedQuery<StudentPersonalDetails>) em.createQuery(query);
		List<StudentPersonalDetails> e= (List<StudentPersonalDetails>) q.getResultList();
		
	return e;
	}
	
	public List<StudentPersonalDetails> getStudPersonalInfo(CreateUser user)
	{
		 
	    String query="from CreateUser where rollNo='"+user.getRollNo()+"'";
		TypedQuery<CreateUser> q=(TypedQuery<CreateUser>) em.createQuery(query);
		List<CreateUser> e= (List<CreateUser>) q.getResultList();
		List<StudentPersonalDetails> per=getStudentPersonalInfo(e);
		for(CreateUser crUser:e)
		{
			for(StudentPersonalDetails p:per)
			{
				crUser.setStudent(p);
				p.setCrUser(crUser);
				System.out.println(p.getfName());
			}
		}
	return per;
	}
	/* This code for Admin,Teacher Email Exist Or Not */
	
	@Transactional
	public boolean getEmailId(String emailId) {
		 String query="from UserRegistration where emailId='"+emailId+"'";
			TypedQuery<UserRegistration> q=(TypedQuery<UserRegistration>) em.createQuery(query);
			List<UserRegistration> e= (List<UserRegistration>) q.getResultList();
			
			 for(UserRegistration u:e)
			 {
				 if(u.getEmailId().equals(emailId))
				 {
					 return true;
				 }
			 }
		return false;
	}
	
	/* This code for Student password change */
	
	@Transactional
	public String updatePassword(String userName, String oldPassword, String newPassword) {
		CreateUser cUser=new CreateUser();
			cUser.setRollNo(userName);
			cUser.setPassword(oldPassword);
			List<CreateUser> cUserList=getStudent(cUser);
			int flag=0;
			
			for(CreateUser c:cUserList)
			{
				if(c.getPassword().equals(oldPassword) && c.getRollNo().equals(userName))
				{
					c.setRollNo(userName);
					c.setPassword(newPassword);
					em.merge(c);
					flag=1;				
				} 
				
			}
			if(flag==0) 
			{
				return "Please Enter the Correct Password";
			}
			else
				return "Password Updated SuccessFully";
	}
	
	@Transactional
	public List<PortalImages> getAllPortalImages()
	{
	
		String sql="from PortalImages";
		TypedQuery<PortalImages> q=(TypedQuery<PortalImages>)em.createQuery(sql);
			List<PortalImages> e=q.getResultList();
		return e;
	}
	
	@Transactional
	public List<CreateUser> getAllStudentData()
	{
	
		String sql="from CreateUser";
		TypedQuery<CreateUser> query=(TypedQuery<CreateUser>)em.createQuery(sql);
			List<CreateUser> usersList=query.getResultList();
		return usersList;
	}

	@Transactional
	public List<Event> getAllEventsData() {
		String sql="from Event";
		TypedQuery<Event> query=(TypedQuery<Event>)em.createQuery(sql);
			List<Event> eventsList=query.getResultList();
		return eventsList;
	}


	public Map<String,String> getAllCalendarEventsData() {
		 
		String sql="from CalendarEvents";
		Map<String,String>calendarEvents=new TreeMap<String, String>();
		TypedQuery<CalendarEvents> query=(TypedQuery<CalendarEvents>)em.createQuery(sql);
			List<CalendarEvents> eventsList=query.getResultList();
			for(CalendarEvents cevents:eventsList)
			{
				calendarEvents.put(cevents.getEvent_Name(),cevents.getEvents_Date());
			}
		return calendarEvents;
	}

	@Transactional
	public String updateAdminPassword(String userName, String oldPassword, String newPassword)
	{
		UserRegistration regi=new UserRegistration();
		regi.setUserName(userName);
		regi.setPassword(oldPassword);
		List<UserRegistration> cUserList=getUser(regi);
		int flag=0;
		
		for(UserRegistration c:cUserList)
		{
			if(c.getPassword().equals(oldPassword) && c.getUserName().equals(userName))
			{
				c.setUserName(userName);
				c.setPassword(newPassword);
				em.merge(c);
				flag=1;				
			} 
			
		}
		if(flag==0) 
		{
			return "Please Enter the Correct Password";
		}
		else
			return "Password Updated SuccessFully";
	
	}
	
	@Transactional
	public List<PlacedStudents> fetchPlacmentRecords(String batch) {
		List<PlacedStudents> placedStudentsList;
		try {
			List<CdacBatches>b=getBatch(batch);
			
			TypedQuery<PlacedStudents>  query=(TypedQuery<PlacedStudents>)em.createQuery("from PlacedStudents where batch='"+b.get(0).getId()+"'");
			placedStudentsList=query.getResultList();
			return placedStudentsList;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Transactional
	public List<CdacBatches> getBatches()
	{
		
		String sql="from CdacBatches";
		TypedQuery<CdacBatches> query=(TypedQuery<CdacBatches>)em.createQuery(sql);
			List<CdacBatches> cdacList=query.getResultList();
		return cdacList;
	}
	
	@Transactional
	public List<CdacBatches> getBatch(String batch)
	{
		
		String sql="from CdacBatches where batch='"+batch+"'";
		TypedQuery<CdacBatches> query=(TypedQuery<CdacBatches>)em.createQuery(sql);
			List<CdacBatches> cdacList=query.getResultList();
		return cdacList;
	}
	
	@Transactional
	public List<PgDetails> getAllpgdetails()
	{
		
		String sql="from PgDetails";
		TypedQuery<PgDetails> q=(TypedQuery<PgDetails>)em.createQuery(sql);
			List<PgDetails> e=q.getResultList();
		return e;
	}


	public List<Course> getCourses() {
		String sql="from Course";
		TypedQuery<Course> q=(TypedQuery<Course>)em.createQuery(sql);
			List<Course> e=q.getResultList();
		return e;
	}


	public List<Subjects> getAllSubjectsList() {
		String sql="from Subjects";
		TypedQuery<Subjects> q=(TypedQuery<Subjects>)em.createQuery(sql);
			List<Subjects> e=q.getResultList();
		return e;
	}
	
	public List<Result> getResult(int subject,int rollNo,int course) {
		String sql="from Result where subject_id='"+subject+"'and course_id='"+course+"student_id="+rollNo+"'";
		TypedQuery<Result> q=(TypedQuery<Result>)em.createQuery(sql);
			List<Result> e=q.getResultList();
		return e;
	}
}
