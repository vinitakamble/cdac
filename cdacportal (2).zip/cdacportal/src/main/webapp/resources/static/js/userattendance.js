/*function attachmentsUploaded()
{ 
	    var form=document.forms["tenMarksheet"];
	//	var tenMarksheet=$('#tenMarksheet').val();
  	    var formData = new FormData(form);
  	   alert(formData);
  	    // Ajax call for file uploaling
  	      $.ajax({
			    	      url : '../attachment.page',
			    	      type : 'POST',
			    	      data : formData,
			    	      cache : false,
			    	      contentType : false,
			    	      processData : false,
			    	      success:function()
			    	      {
			    	    	 alert("success");
			    	      }
  	      		});      		
  	   return false; 
}
*/


function events()
	{
		var event_name=$('#event_name').val();
		var event_date=$('#event_date').val();
		var event_description=$('#event_description').val();
		
		if(event_name!="" && event_date!="" && event_description!="")
		{
			//alert(event_description);
			$.ajax({
				url:'../eventcontroller',
				data:"event_name="+event_name+"&event_date="+event_date+"&event_description="+event_description,
				method:"POST",
				success:function(data)
				{
					alert(data);
				}
					
			});
		}
		else
		{
			alert("Please Fill All Details")
		}
		
		
	}






function excelUploaded()
{ 
		
  	    var form = document.forms[0];
  	    var formData = new FormData(form);
  	   
  	    // Ajax call for file uploaling
  	      $.ajax({
			    	      url : '/createuser',
			    	      type : 'POST',
			    	      data : formData,
			    	      cache : false,
			    	      contentType : false,
			    	      processData : false,
			    	      success:function(data)
			    	      {
			    	    	 alert(data);
			    	      }
  	      		});
  	      			
  	  return false; 
}

function changePassword(action)
{
	var userName=$("#userName").val();
	var oldPassword=$("#oldPassword").val();
	var newPassword=$("#newPassword").val();
	if(userName!="" && oldPassword!="" && newPassword!="")
	{
		//alert(userName+" "+oldPassword+" "+newPassword);
		 $.ajax({
		      url : 'changePassword.page?userName='+userName+"&oldPassword="+oldPassword+"&newPassword="+newPassword+"&action="+action,
		      type : 'POST',
		      success:function(data)
		      {
		    	 alert(data);
		    	 $('#myModal').modal('hide');
		      }
		});
	}
	else
	{
		alert("Please Enter the all Details");
	}
}




    	
    


/*function userAttendance()
{	
	var user_id=$("#user_id").val();
	var time=$("#time").val();
	var attendance=$("#attendance").val();
	var att_date=$("#att_date").val();
		alert(user_id+" "+time+" "+attendance+" "+att_date);
}*/


