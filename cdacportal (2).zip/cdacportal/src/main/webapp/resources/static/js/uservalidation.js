function userExist()
{
	
	var userName=$("#userName").val();
	
	$.ajax({
		
		url:"validUser?userName="+userName,
		method:"POST",
		success:function(data)
		{
			  
				if(data==""+true)
				{
					$("#spanid").text("User Already Exist");
					$("#spanid").css({"color":"red"});
				}
				else
				{
					$("#spanid").text("");
				}
		}
			
		
	});

}

function validEmail()
{
	
	var emailId=$("#emailId").val();
	
	$.ajax({
		
		url:"validEmail?emailId="+emailId,
		method:"POST",
		success:function(data)
		{
			  
				if(data==""+true)
				{
					$("#emailid").text("EmailID Already Exist");
					$("#emailid").css({"color":"red"});
				}
				else
				{
					$("#emailid").text("");
				}
		}
			
		
	});

}

function validate(image,span_id)
{
		
		if(image!='')
		{
			var checkimg = image.toLowerCase();
				if (!checkimg.match(/(\.jpg|\.png|\.JPG|\.PNG|\.jpeg|\.JPEG)$/))
				{
					span_id.text("Please Select File Extensions only .jpg,.png,.jpeg");
					span_id.css({"color":"red"});
					//document.getElementById("file_upload").focus();
					return false;
				}
		}
		return true;
} 


function validatePDF(pdfFile,span_id,id_val)
{
		
		if(pdfFile!='' && id_val==1)
		{
			var checkpdf = pdfFile.toLowerCase();
				if (!checkpdf.match(/(\.pdf)$/))
				{
					span_id.text("Please Select File Extensions only .pdf");
					span_id.css({"color":"red"});
					return false;
				}
		}
		else if(pdfFile!='' && id_val==2)
		{
			var checkpdf = pdfFile.toLowerCase();
			if (!checkpdf.match(/(\.zip)$/))
			{
				span_id.text("Please Select File Extensions only .zip");
				span_id.css({"color":"red"});
				
				return false;
			}
		}
		else if(pdfFile!='' && id_val==3)
		{
			var checkpdf = pdfFile.toLowerCase();
			if (!checkpdf.match(/(\.xls|\.xlsx)$/))
			{
				span_id.text("Please Select File Extensions only .xls and .xlsx");
				span_id.css({"color":"red"});
				
				return false;
			}
		}
		return true;
} 


function amountValidate()
{
	if($('#amount').val()=="")
	{
		$('#amountspan').text("Amount Can't be Empty");
		$('#amountspan').css({'color':'red'});
		$('#amount').css({'bordercolor':'red'});
		 return false;
	}
	else
	{
		$('#amountspan').text(" ");
		$('#amountspan').css({'color':'green'});
		$('#amount').css({'bordercolor':'green'});
	}
}

function firstnameCheck(){

	var name = document.getElementById("fnme").value;
   
    if(name == ""){
    	  document.getElementById("fnamespan").innerHTML="* Name can't be Empty.";
	       document.getElementById("fnamespan").style.color="red";
	      document.getElementById("fnme").style.borderColor="red";
	   
	        return false;
    }
    if (name.search("[a-zA-Z]")==-1 || name.search("[0-9]")>-1)                                  
    { 
   
       document.getElementById("fnamespan").innerHTML="* Name contains only aphabets.";
       document.getElementById("fnamespan").style.color="red";
       document.getElementById("fnme").style.borderColor="red";
        
        return false; 
    } 
    else
     {
         document.getElementById("fnamespan").innerHTML="";
         document.getElementById("fnamespan").style.color="green";
         document.getElementById("fnme").style.borderColor="green";
         

     }             
    }



function middlenameCheck(){

	var name = document.getElementById("mnme").value;
   
 if(name == ""){
 	  document.getElementById("mnamespan").innerHTML="* Middle name can't be Empty.";
       document.getElementById("mnamespan").style.color="red";
      document.getElementById("mnme").style.borderColor="red";
        //name.focus(); 
        return false;
 }
    if (name.search("[a-zA-Z]")==-1 || name.search("[0-9]")>-1)                                  
    { 
      //  window.alert("Please enter your name."); 
       document.getElementById("mnamespan").innerHTML="* Middle name contains only aphabets.";
       document.getElementById("mnamespan").style.color="red";
      document.getElementById("mnme").style.borderColor="red";
        //name.focus(); 
        return false; 
    } 
    else
     {
         document.getElementById("mnamespan").innerHTML="";
         document.getElementById("mnamespan").style.color="green";
         document.getElementById("mnme").style.borderColor="green";


     }             
    }

function lastnameCheck(){

	var name = document.getElementById("lnme").value;
   
if(name == ""){
	  document.getElementById("lnamespan").innerHTML="* Last name can't be Empty.";
       document.getElementById("lnamespan").style.color="red";
      document.getElementById("lnme").style.borderColor="red";
        //name.focus(); 
        return false;
}
    if (name.search("[a-zA-Z]")==-1 || name.search("[0-9]")>-1)                                  
    { 
      //  window.alert("Please enter your name."); 
       document.getElementById("lnamespan").innerHTML="* Last name contains only aphabets.";
       document.getElementById("lnamespan").style.color="red";
      document.getElementById("lnme").style.borderColor="red";
        //name.focus(); 
        return false; 
    } 
    else
     {
         document.getElementById("lnamespan").innerHTML="";
         document.getElementById("lnamespan").style.color="green";
         document.getElementById("lnme").style.borderColor="green";


     }             
    }

function usernameCheck(){

	var name = document.getElementById("userName").value;
   var uname=/^[a-zA-Z0-9]{10}/;

    if (name.match(uname))                                  
    { 
      //  window.alert("Please enter your name."); 
       document.getElementById("unamespan").innerHTML="* User name contains aphanumeric only and it not exceed than 10 charactors.";
       document.getElementById("unamespan").style.color="red";
      document.getElementById("userName").style.borderColor="red";
        //name.focus(); 
        return false; 
    } 
    else
     {
         document.getElementById("unamespan").innerHTML="";
         document.getElementById("unamespan").style.color="green";
         document.getElementById("userName").style.borderColor="green";

     }
	if(name == ""){
	  		document.getElementById("unamespan").innerHTML="* Please don't leave the field empty.";
	    document.getElementById("unamespan").style.color="red";
	    document.getElementById("userName").style.borderColor="red";
	        //name.focus(); 
	        return false;
			 }
    }



function pwdcheck() {
var lmark = document.getElementById("password").value;

if(lmark == "")
{
	 document.getElementById("PassSpan").innerHTML="* Please Enter the Pssword ";
     document.getElementById("PassSpan").style.color="red";
	 document.getElementById("password").style.borderColor="red";     
	  
     return false;
}
 else{
	 document.getElementById("PassSpan").innerHTML=" ";
     document.getElementById("PassSpan").style.color="green";
	 document.getElementById("password").style.borderColor="green";

} 
document.getElementById("PassSpan").hidden;
}  

function  emailcheck()

{        

var reg1 = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

var name = document.getElementById("emailId").value;
if (reg1.test(name) )                               
 { 
document.getElementById("emailspan").innerHTML=" ";
document.getElementById("emailspan").style.color="green";
document.getElementById("emailId").style.borderColor="green";
      
} 
else
{
 document.getElementById("emailspan").innerHTML="* Please enter valid emailid";
 document.getElementById("emailspan").style.color="red";
 document.getElementById("emailId").style.borderColor="red";
} 
}

function  mobilenocheck()

{        
 var name = document.getElementById("mobi").value;

var  p=/^[789]\d{9}$/;
if (p.test(name))                                  
{ 
  
  document.getElementById("mobispan").innerHTML="";

   document.getElementById("mobispan").style.color="green";
   document.getElementById("mobi").style.borderColor="green";
  
  
} 
else
{          
	document.getElementById("mobispan").innerHTML="* Please enter valid mobile no";

    document.getElementById("mobispan").style.color="red";
    document.getElementById("mobi").style.borderColor="red";
} 
}

function  fmobilenocheck()

{        
 var name = document.getElementById("fmobi").value;

var  p=/^[789]\d{9}$/;
if (p.test(name))                                  
{ 
  
  document.getElementById("fmobispan").innerHTML="";

   document.getElementById("fmobispan").style.color="green";
   document.getElementById("fmobi").style.borderColor="green";
  
  
} 
else
{          
	document.getElementById("fmobispan").innerHTML="* Please enter valid mobile no";

    document.getElementById("fmobispan").style.color="red";
    document.getElementById("fmobi").style.borderColor="red";
} 
}

function  pincodecheck()

{
    var pincode = document.getElementById("pin").value;
    pat2=/^[a-zA-Z]/;
    pat1=/^\d{6}$/;
    if(pat1.test(pincode))
    {

        document.getElementById("pincodespan").innerHTML=" ";
        document.getElementById("pincodespan").style.color="green";
   		document.getElementById("pin").style.borderColor="green";
   return false;
    }
    else{
        document.getElementById("pincodespan").innerHTML="* Please Enter valid Pin code.. ";
        document.getElementById("pincodespan").style.color="red";
        document.getElementById("pin").style.borderColor="red";

    } document.getElementById("pincodespan").hidden;
    
    if(pincode.length<6 || pincode.length>6)
    	{
	        	document.getElementById("pincodespan").innerHTML="* Pincode should be 6 digits";
	            document.getElementById("pincodespan").style.color="red";
	            document.getElementById("pin").style.borderColor="red";
	           
        }
}

function flatnocheck(){
 var flatno = document.getElementById("fno").value;
 
	if(flatno == ""){
		 document.getElementById("flatnospan").innerHTML="* Please Enter the FlatNo ";
         document.getElementById("flatnospan").style.color="red";
    	 document.getElementById("fno").style.borderColor="red";     
    	  
	     return false;
}
    else{
    	 document.getElementById("flatnospan").innerHTML=" ";
         document.getElementById("flatnospan").style.color="green";
    	 document.getElementById("fno").style.borderColor="green"; 

    } document.getElementById("flatnospan").hidden;
}

function housenocheck() {
 var houseno = document.getElementById("hno").value;
 
	if(houseno == ""){
		 document.getElementById("housenospan").innerHTML="* Please Enter the House No ";
         document.getElementById("housenospan").style.color="red";
    	 document.getElementById("hno").style.borderColor="red";     
    	  
	     return false;
	}
	 else{
		 document.getElementById("housenospan").innerHTML=" ";
         document.getElementById("housenospan").style.color="green";
    	 document.getElementById("hno").style.borderColor="green";

    } document.getElementById("housenospan").hidden;
} 

function lmarkcheck() {
 var lmark = document.getElementById("lmark").value;

	if(lmark == ""){
		 document.getElementById("landmarkspan").innerHTML ="* Please Enter the land Mark";
         document.getElementById("landmarkspan").style.color="red";
    	 document.getElementById("lmark").style.borderColor="red";     
    	  
	     return false;
	}
	 else{
		 document.getElementById("landmarkspan").innerHTML=" ";
         document.getElementById("landmarkspan").style.color="green";
    	 document.getElementById("lmark").style.borderColor="green";

    } document.getElementById("landmarkspan").hidden;
} 

function statecheck() {
 var state = document.getElementById("state").value;
 
	if(state == ""){
		 document.getElementById("statespan").innerHTML="* Please Enter the State ";
         document.getElementById("statespan").style.color="red";
    	 document.getElementById("state").style.borderColor="red";     
    	  
	     return false;
	}
	 else{
		 document.getElementById("statespan").innerHTML=" ";
         document.getElementById("statespan").style.color="green";
    	 document.getElementById("state").style.borderColor="green";

    } document.getElementById("statespan").hidden;
}

function statecheck() {
	 var state = document.getElementById("state").value;
	 
		if(state == ""){
			 document.getElementById("statespan").innerHTML="* Please Enter the State ";
	         document.getElementById("statespan").style.color="red";
	    	 document.getElementById("state").style.borderColor="red";     
	    	  
		     return false;
		}
		 else{
			 document.getElementById("statespan").innerHTML=" ";
	         document.getElementById("statespan").style.color="green";
	    	 document.getElementById("state").style.borderColor="green";

	    } document.getElementById("statespan1").hidden;
	}

function statecheck1() {
		 var state = document.getElementById("crrstate").value;
		 
			if(state == ""){
				 document.getElementById("statespan1").innerHTML="* Please Enter the State ";
		         document.getElementById("statespan1").style.color="red";
		    	 document.getElementById("crrstate").style.borderColor="red";     
		    	  
			     return false;
			}
			 else{
				 document.getElementById("statespan1").innerHTML=" ";
		         document.getElementById("statespan1").style.color="green";
		    	 document.getElementById("crrstate").style.borderColor="green";

		    } document.getElementById("statespan1").hidden;
		}


function streetcheck() {
 var street = document.getElementById("street").value;
 
	if(street == ""){
		 document.getElementById("streetspan").innerHTML="* Please Enter the Street ";
         document.getElementById("streetspan").style.color="red";
    	 document.getElementById("street").style.borderColor="red";     
    	  
	     return false;
	}
	 else{
		 document.getElementById("streetspan").innerHTML=" ";
         document.getElementById("streetspan").style.color="green";
    	 document.getElementById("street").style.borderColor="green";

    } document.getElementById("streetspan").hidden;
}

function citycheck() {
 var city = document.getElementById("city").value;
 
	if(city == ""){
		 document.getElementById("cityspan").innerHTML="* Please Enter the City ";
         document.getElementById("cityspan").style.color="red";
    	 document.getElementById("city").style.borderColor="red";     
    	  
	     return false;
	}
	 else{
		 document.getElementById("cityspan").innerHTML=" ";
         document.getElementById("cityspan").style.color="green";
    	 document.getElementById("city").style.borderColor="green";

    } document.getElementById("cityspan").hidden;
}	 

function citycheck1() {
	 var city = document.getElementById("crrcity").value;
	 
		if(city == ""){
			 document.getElementById("cityspan1").innerHTML="* Please Enter the City ";
	         document.getElementById("cityspan1").style.color="red";
	    	 document.getElementById("crrcity").style.borderColor="red";     
	    	  
		     return false;
		}
		 else{
			 document.getElementById("cityspan1").innerHTML=" ";
	         document.getElementById("cityspan1").style.color="green";
	    	 document.getElementById("crrcity").style.borderColor="green";

	    } document.getElementById("cityspan1").hidden;
	}	 


function StudentUserName() {
	var lmark = document.getElementById("rollNo").value;

	if(lmark == ""){
		 document.getElementById("rollNoSpan").innerHTML="* Please Enter the rollNo ";
	     document.getElementById("rollNoSpan").style.color="red";
		 document.getElementById("rollNo").style.borderColor="red";     
		  
	     return false;
	}
	 else{
		 document.getElementById("rollNoSpan").innerHTML=" ";
	     document.getElementById("rollNoSpan").style.color="green";
		 document.getElementById("rollNo").style.borderColor="green";

	} 
	     document.getElementById("rollNoSpan").hidden;
	}  


function contactUs() {
	var lmark = document.getElementById("subject").value;

	if(lmark == ""){
		 document.getElementById("subSpan").innerHTML="* Please Enter the Subject ";
	     document.getElementById("subSpan").style.color="red";
		 document.getElementById("subject").style.borderColor="red";     
		  
	     return false;
	}
	 else{
		 document.getElementById("subSpan").innerHTML=" ";
	     document.getElementById("subSpan").style.color="green";
		 document.getElementById("subject").style.borderColor="green";

	} 
	     document.getElementById("subSpan").hidden;
	}  


function contactUsForMessage() {
	var lmark = document.getElementById("message").value;

	if(lmark == ""){
		 document.getElementById("msgSpan").innerHTML="* Please Enter the Subject ";
	     document.getElementById("msgSpan").style.color="red";
		 document.getElementById("message").style.borderColor="red";     
		  
	     return false;
	}
	 else{
		 document.getElementById("msgSpan").innerHTML=" ";
	     document.getElementById("msgSpan").style.color="green";
		 document.getElementById("message").style.borderColor="green";

	} 
	     document.getElementById("msgSpan").hidden;
	}  


function eventCheck() 
{
	 var city = document.getElementById("event_name").value;
	 
		if(city == "")
		{
			 document.getElementById("eventspan").innerHTML="* Please Enter the Event.";
	         document.getElementById("eventspan").style.color="red";
	    	 document.getElementById("event_name").style.borderColor="red";     
	    	  
		     return false;
		}
		 else
		 {
			 document.getElementById("eventspan").innerHTML=" ";
	         document.getElementById("eventspan").style.color="green";
	    	 document.getElementById("event_name").style.borderColor="green";

		 } 
		document.getElementById("eventspan").hidden;
}	 
