$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
});
