function copyAddress()
{		
		$("#crrstate").val($("#state").val());
		$("#crrcity").val($("#city").val());
		$("#crrAddress").val($("#perAddress").val());
}

function calPercentage(total,obtain,id)
{
	var per=(obtain/total)*100;
	
	if(id==1)
		$("#tenPercentage").val(per.toFixed(2));
	else if(id==2)
		$("#twelvePercentage").val(per.toFixed(2));
	else if(id==3)
		$("#DPercentage").val(per.toFixed(2));
	else
		$("#gPercentage").val(per.toFixed(2));
}

function showTable(id)
{
	if(id==1)
		document.getElementById('table').style.visibility = "hidden";
	else
		document.getElementById('table').style.visibility = "visible";
}

$( function() {
    $( "#datepicker6" ).datepicker();
    $( "#datepicker7" ).datepicker();
  } );