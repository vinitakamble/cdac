 function initMap() 
 {
        var myLatLng = {lat: 19.1096456, lng: 72.8338119};

        var map = new google.maps.Map(document.getElementById('map'),
        {
          zoom: 18,
          center: myLatLng,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        var marker = new google.maps.Marker({
          position: myLatLng,
          map: map,
          title: 'CDAC JUHU'
        });
 }    
 
 
 
 function sendMail()
 {
	var mailTo=$("#mailTo").val();
	var subject=$("#subject").val();
	var message=$("#message").val();
		if(mailTo!="" && subject!="" && message!="")
		{
			$.ajax({
				method:"post",
				url:"EmailService",
				data:"mailTo="+mailTo+"&subject="+subject+"&message="+message,
				success:function(data)
				{
				   alert(data);
				}	
			});
		}
		else
		{
			alert("Please Fill the subjet and message");
		}
	
 }